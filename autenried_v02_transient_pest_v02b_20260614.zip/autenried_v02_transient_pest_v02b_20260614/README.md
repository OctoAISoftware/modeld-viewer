# Autenried — Modelo Transiente v02 + Calibração PEST++ v02B

Pacote de documentação local — gerado em **2026-06-14**.

Contém o modelo MODFLOW 6 transiente **v02** (já calibrado) do sítio Autenried e o
*kit* da calibração focada **PEST++ v02B** (otimização só de Sy), além dos scripts,
do visualizador 3D e dos resultados do *history match*.

> **Importante:** os binários brutos pesados (`.hds`, `.cbc`, `.lst` e os arranjos de
> entrada grandes do MF6) **não** estão neste zip — juntos passam de 18 GB. Em vez deles
> estão os scripts FloPy que **regeram** tudo (ver "Como reproduzir"). O que está aqui é
> tudo que é leve e que documenta o modelo de ponta a ponta.

---

## 1. O que é o modelo transiente v02

Modelo de fluxo subterrâneo do sítio **Autenried** (projeto Catchment_Autenried), em
**MODFLOW 6 / FloPy**. O objetivo é reproduzir a dinâmica transiente de cargas
hidráulicas sob bombeamento e recarga sazonal, partindo da solução em regime
permanente (SS) já calibrada por PEST++.

**Grade e tempo (arquivos reais deste pacote):**
- Grade: **19 camadas × 403 linhas × 577 colunas** (~2,1 milhões de células ativas).
- **48 períodos de estresse** transientes (passo diário, ~1.096 dias no total).
- Recarga transiente mensal (Thornthwaite) em zonas espaciais; cronograma de bombeamento
  refinado a partir da análise de derivada do poço AUT-03 (16 transições, ~ -432 a -480 m³/d).
- K (Kxy + Kz) e condições de contorno (CHD/GHB) herdadas da **calibração SS** (PEST++ V12 SS).
- GHB do modelo, IC vindo do `.hds` do permanente V12.

> Nota: o *briefing* da tarefa citou "5 camadas, 155×185, 6 zonas de K". Os arquivos
> reais em produção são maiores (19 camadas, 403×577, zonas K da calibração SS). Este
> README descreve **o que os arquivos realmente contêm**.

**Desempenho do *history match* v02 (linha de base):**

| Métrica | Valor |
|---|---|
| MAE | **0,237 m** |
| RMSE | **0,299 m** |
| Viés | **+0,034 m** |
| R (correlação) | **0,5734** |
| Pontos | 3.230 medições diárias em 7 poços AUT |
| Duração | 48 períodos de estresse, ~4h19min de *wall-time* |

Gráficos do *match* em `modelo_transiente_v02/plots/` (4 figuras) e a tabela ponto-a-ponto
em `modelo_transiente_v02/sim_vs_obs.csv`.

---

## 2. Ordem de execução dos scripts

Cada passo abaixo na ordem em que foi rodado. Os scripts citados estão neste pacote
(pasta entre parênteses).

1. **Construir o modelo MF6 transiente** — `pest_v02B/run_v12_transient_v02.py`.
   Script FloPy "mestre" do v02 (~930 linhas): monta a grade DIS, TDIS (48 SPs), NPF
   (K da calibração SS), STO (Sy/Ss por zona), RCHA (recarga mensal Thornthwaite),
   WEL (cronograma de bombeamento), GHB/CHD (contornos), IC (do `.hds` permanente) e o
   solver IMS. Escreve todos os arquivos de entrada do MF6 em `mf6_workspace/`.

2. **Rodar o permanente (SS)** — a solução SS já calibrada (PEST++ V12 SS: 9 zonas Kxy +
   9 Kz, phi≈35,95, 10 iterações) é a base congelada. O `.hds` do SS vira a condição
   inicial (IC) do transiente. *(A pasta da calibração SS fica em outra árvore do projeto
   — `v12_pest_base` — e não foi incluída aqui por ser separada e pesada.)*

3. **Rodar o transiente** — execução do `mf6` sobre `mf6_workspace/mfsim.nam`. Gera
   `gwf_tr_v02.hds` (cargas), `gwf_tr_v02.cbc` (balanço) e os `.lst`. **Esses binários
   não estão no zip** (somam >16 GB); são regerados rodando o passo 1 + `mf6`.

4. **Extrair cargas / rebaixamento e fazer o *match*** — o próprio
   `run_v12_transient_v02.py` extrai as cargas simuladas nos 7 poços de observação
   (`obs_daily.csv` como referência), calcula resíduos vs. observado, escreve
   `sim_vs_obs.csv` e `aut_heads.csv`, e plota as figuras em `plots/`
   (séries individuais, *overlay*, resíduos no tempo, *scatter* sim×obs).

5. **Montar o setup PEST++ v02B** — `pest_v02B/build_v02B_pest.py`. Gera o arquivo de
   controle `pst_v02B.pst`, o *template* `sy_params.dat.tpl` (injeção dos 5 Sy) e a
   *instruction* `sim_heads.csv.ins` (leitura das cargas simuladas). O *forward runner*
   chamado pelo PEST++ a cada rodada é `forward_v02B.py` (lê `sy_params.dat`, reconstrói
   e roda o MF6 com aqueles Sy, tudo o mais congelado, e escreve `sim_heads.csv`).
   `dry_run_walltime.py` estima o *wall-time* sem rodar o modelo.

6. **Lançar o PEST++** — `pest_v02B/launch_v02B.sh` ativa o ambiente `pestpp_env` e
   dispara `pestpp-glm pst_v02B.pst` (ver status na seção 3).

7. **Pós-processar / visualizar** — `modelo_transiente_v02/viewer/build_viewer.py`
   (e `modflow_3d_html_viewer.py`) leem a grade + `.hds` (read-only) e geram o
   visualizador 3D autocontido `autenried_v02_viewer.html` (Plotly embutido, 3 abas:
   Head / K zones / Drawdown, *slider* dos 48 períodos, overlay GHB). Os scripts `probe*.py`
   foram usados para conferir dimensões, zonas K e recarga.

---

## 3. Status da calibração PEST++ v02B

> **Rodando em paralelo, NÃO foi tocado neste empacotamento (acesso read-only).**

- **Motor:** `pestpp-glm` v5.2.25, modo **serial**.
- **PID:** `2133554` · **início:** sáb 13/06/2026 14:19 (horário do servidor).
- **Decorrido até 14/06 ~09:18:** ~19 h · **estimativa total:** ~43 h (Jacobiano + lambdas)
  → faltam ~24 h. Está na **iteração 1** (montando/rodando o Jacobiano da solução base).
- **NOPTMAX:** 5 · lambdas 0,1 / 1 / 10 / 100 / 1000.

**Livres (5 parâmetros de *Specific Yield*):**

| Zona | Parâmetro | Inicial | Limites |
|---|---|---|---|
| Z2 | sy_z02 | 0,15 | 0,05–0,35 |
| Z3 | sy_z03 | 0,18 | 0,05–0,35 |
| Z4 | sy_z04 | 0,22 | 0,05–0,35 |
| Z5 | sy_z05 | 0,10 | 0,03–0,30 |
| Z6 | sy_z06 | 0,20 | 0,05–0,35 |

**Congelados** na solução calibrada v02: **K (Kxy+Kz), RCH, cronograma de bombeamento,
Ss, CHD, GHB, IC.** Sy das zonas Z1 (0,05), Z7 (0,10), Z8 (0,12), Z9 (0,03) também fixos.

**Metas:** MAE < 0,237 m, viés mais próximo de 0 que +0,034 m, melhor R que 0,574, sem
divergência nos 48 SPs (o v03, com 15+ parâmetros livres, divergiu no SP38 — por isso o
v02B é conservador: só Sy, NOPTMAX=5).

Saídas parciais do PEST++ em `pest_v02B/outputs/` — destaque para `pst_v02B.rec` (registro
legível), `.par` (parâmetros atuais), `.iobj` (função objetivo por iteração). Como a
iteração 1 ainda não fechou, `.iobj` traz só o cabeçalho.

---

## 4. O que está / não está no zip

**Incluído:**
- `modelo_transiente_v02/mf6_inputs/` — arquivos de entrada **leves** do MF6 (NAM, OC, OBS,
  TDIS, IMS, CHD, GHB, WEL) + `aut_heads.csv`.
- `modelo_transiente_v02/sim_vs_obs.csv`, `obs_daily.csv`, `stress_period_summary.csv`.
- `modelo_transiente_v02/plots/` — 4 figuras do *history match* v02.
- `modelo_transiente_v02/viewer/autenried_v02_viewer.html` — visualizador 3D autocontido +
  `build_viewer.py` e `probe*.py`; `modflow_3d_html_viewer.py` na raiz do modelo.
- `pest_v02B/` — todos os scripts (build/forward/run/launch/dry-run), o controle
  `pst_v02B.pst`, *template* e *instruction*, e `outputs/` com as saídas parciais.
- `pest_v02B/kit/` — cópia companheira do kit (obs_locs, par_table, READMEs auxiliares).

**NÃO incluído (pesado demais — regerar; ver seção 5):**
- `gwf_tr_v02.hds` (~1,7 GB), `gwf_tr_v02.cbc` (~13 GB), `gwf_tr_v02.lst` (~2,7 GB).
- Arranjos de entrada grandes do MF6: `.dis` (92 MB), `.dis.grb` (148 MB), `.npf` (238 MB),
  `.ic` (75 MB), `.rcha` (182 MB), `.sto` (159 MB).
- `mf6_run/` do diretório PEST++ (≈4,6 GB, *workspace* da rodada em curso).
- Visualizador antigo `v02_3d_viewer.html` (36 MB) — substituído por `viewer/autenried_v02_viewer.html`.

---

## 5. Como reproduzir localmente

**Dependências Python:** `flopy`, `numpy`, `pandas`, `matplotlib`, `plotly`,
`pyemu`/`pestpython` (utilitários PEST). Ambientes usados na origem (micromamba):
`mf6env` (MODFLOW 6) e `pestpp_env` (PEST++).

**Executáveis:**
- **MODFLOW 6** (`mf6`) — versão do `mf6env`.
- **PEST++** — `pestpp-glm` **v5.2.25**.

**Passos:**
```bash
# 1) Regerar todas as entradas do MF6 e rodar o transiente v02
python pest_v02B/run_v12_transient_v02.py
#    -> escreve mf6_workspace/ e roda o mf6; gera .hds/.cbc/.lst e sim_vs_obs.csv

# 2) Regerar o setup PEST++ v02B (se quiser refazer .pst/.tpl/.ins)
python pest_v02B/build_v02B_pest.py

# 3) Lançar a calibração (serial)
bash pest_v02B/launch_v02B.sh        # dispara pestpp-glm pst_v02B.pst

# 4) Regerar o visualizador 3D (read-only sobre o .hds)
python modelo_transiente_v02/viewer/build_viewer.py
```

> Ajuste os caminhos absolutos no topo dos scripts (`MF6_EXE`, `BASE_DIR`, etc.) para a
> sua máquina. Os scripts assumem a árvore `Catchment_Autenried_flopy/V12_TRANSIENT_V02`
> ao lado de `V12_TRANSIENT_V02B_PEST`.

---

*Empacotado read-only; a rodada PEST++ v02B em andamento não foi interrompida nem alterada.*
