#!/usr/bin/env python3
"""
forward_v02B.py — FloPy Forward Runner for PEST++ v02B
=======================================================
Called by PEST++ at each iteration. Reads Sy values from sy_params.dat,
builds and runs the MF6 transient model with those Sy values (everything
else frozen from v02), and outputs simulated heads to sim_heads.csv.

All paths are relative to the script directory.
"""

import os
import sys
import time
import shutil
import subprocess
import numpy as np
import pandas as pd
from pathlib import Path
from datetime import datetime

SCRIPT_DIR = Path(__file__).parent
V02_DIR = SCRIPT_DIR.parent / "V12_TRANSIENT_V02"
V02_MF6_WS = V02_DIR / "mf6_workspace"
MF6_RUN_DIR = SCRIPT_DIR / "mf6_run"
OBS_DAILY = V02_DIR / "obs_daily.csv"

MF6_EXE = "/home/suporte/micromamba/envs/mf6env/bin/mf6"

NLAY = 19

ALL_SY_FROZEN = {1: 0.05, 7: 0.10, 8: 0.12, 9: 0.03}
FREE_ZONE_IDS = [2, 3, 4, 5, 6]

SY_VALUE_TO_ZONE = {
    0.05: 1, 0.15: 2, 0.18: 3, 0.22: 4,
    0.10: 5, 0.20: 6, 0.10: 7, 0.12: 8, 0.03: 9,
}

ZONE_TO_INITIAL_SY = {
    1: 0.05, 2: 0.15, 3: 0.18, 4: 0.22,
    5: 0.10, 6: 0.20, 7: 0.10, 8: 0.12, 9: 0.03,
}


def read_sy_params():
    """Read current Sy values from sy_params.dat (PEST++ writes this)."""
    params = {}
    param_file = SCRIPT_DIR / "sy_params.dat"
    with open(param_file) as f:
        for line in f:
            line = line.strip()
            if not line or line.startswith("#"):
                continue
            parts = line.split()
            if len(parts) >= 2:
                zone_id = int(parts[0])
                sy_val = float(parts[1])
                params[zone_id] = sy_val
    return params


def prepare_workspace(sy_params):
    """Copy v02 MF6 workspace and modify Sy in the .sto file."""
    if MF6_RUN_DIR.exists():
        shutil.rmtree(MF6_RUN_DIR)
    MF6_RUN_DIR.mkdir(parents=True)

    for f in V02_MF6_WS.iterdir():
        if f.suffix in (".hds", ".cbc", ".lst"):
            continue
        shutil.copy2(f, MF6_RUN_DIR / f.name)

    modify_sto_file(sy_params)


def modify_sto_file(sy_params):
    """Replace Sy values in the .sto file for the free zones."""
    sto_path = MF6_RUN_DIR / "gwf_tr_v02.sto"
    with open(sto_path) as f:
        lines = f.readlines()

    sy_start = None
    for i, line in enumerate(lines):
        if line.strip().startswith("sy") and "LAYERED" in line.upper():
            sy_start = i + 1
            break

    if sy_start is None:
        raise RuntimeError("Cannot find 'sy LAYERED' in .sto file")

    all_sy = dict(ZONE_TO_INITIAL_SY)
    for zone_id, val in sy_params.items():
        all_sy[zone_id] = val
    for zone_id, val in ALL_SY_FROZEN.items():
        all_sy[zone_id] = val

    reverse_map = {}
    for zone_id, sy_val in ZONE_TO_INITIAL_SY.items():
        reverse_map[sy_val] = zone_id

    idx = sy_start
    for lay in range(NLAY):
        if idx >= len(lines):
            break
        if "INTERNAL" in lines[idx] or "END" in lines[idx].upper():
            if "END" in lines[idx].upper():
                break
            idx += 1

        while idx < len(lines):
            stripped = lines[idx].strip()
            if stripped.startswith("INTERNAL") or stripped.startswith("END") or stripped.startswith("TRANSIENT"):
                break
            vals = stripped.split()
            new_vals = []
            for v_str in vals:
                v = float(v_str)
                if v in reverse_map:
                    zone = reverse_map[v]
                    new_vals.append(f"{all_sy[zone]:.8f}")
                else:
                    closest_zone = min(
                        ZONE_TO_INITIAL_SY.items(),
                        key=lambda x: abs(x[1] - v)
                    )
                    if abs(closest_zone[1] - v) < 0.005:
                        new_vals.append(f"{all_sy[closest_zone[0]]:.8f}")
                    else:
                        new_vals.append(v_str)
            lines[idx] = "  ".join(new_vals) + "\n"
            idx += 1

    with open(sto_path, "w") as f:
        f.writelines(lines)


def run_mf6():
    """Execute MODFLOW 6."""
    result = subprocess.run(
        [MF6_EXE],
        cwd=str(MF6_RUN_DIR),
        capture_output=True,
        text=True,
        timeout=28800,
    )
    if result.returncode != 0:
        sys.stderr.write(f"MF6 FAILED (exit {result.returncode})\n")
        sys.stderr.write(result.stderr[:500] + "\n")
        lst_file = MF6_RUN_DIR / "mfsim.lst"
        if lst_file.exists():
            with open(lst_file) as f:
                content = f.read()
            if "FAILED TO CONVERGE" in content:
                sys.stderr.write("SOLVER FAILED TO CONVERGE\n")
        return False
    return True


def extract_sim_heads():
    """Read simulated heads from MF6 output (aut_heads.csv) and write sim_heads.csv."""
    sim_csv = MF6_RUN_DIR / "aut_heads.csv"
    if not sim_csv.exists():
        sys.stderr.write("ERROR: aut_heads.csv not produced by MF6\n")
        return False

    sim_df = pd.read_csv(sim_csv)

    obs_df = pd.read_csv(OBS_DAILY)

    well_col_map = {
        "AUT-01": "aut01", "AUT-02": "aut02", "AUT-03": "aut03",
        "AUT-05": "aut05", "AUT-06": "aut06", "AUT-07": "aut07",
        "AUT-08": "aut08",
    }

    output_rows = []
    for _, obs_row in obs_df.iterrows():
        well = obs_row["well"]
        sim_day = int(obs_row["sim_day"])
        col_name = well_col_map.get(well)

        if col_name and col_name in sim_df.columns:
            time_col = [c for c in sim_df.columns if c.lower() == "time"][0]
            mask = sim_df[time_col].astype(float).astype(int) == sim_day
            if mask.any():
                sim_head = sim_df.loc[mask, col_name].iloc[0]
            else:
                nearest_idx = (sim_df[time_col].astype(float) - sim_day).abs().idxmin()
                sim_head = sim_df.loc[nearest_idx, col_name]
        else:
            sim_head = -999.0

        output_rows.append({"sim_head": float(sim_head)})

    out_path = SCRIPT_DIR / "sim_heads.csv"
    with open(out_path, "w") as f:
        f.write("sim_head\n")
        for row in output_rows:
            f.write(f"{row['sim_head']:.6f}\n")

    return True


def main():
    """Forward model execution for PEST++."""
    t0 = time.time()
    ts_start = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    print(f"[forward_v02B] START: {ts_start}")

    print("[forward_v02B] Reading Sy parameters...")
    sy_params = read_sy_params()
    print(f"  Zones: {sy_params}")

    print("[forward_v02B] Preparing MF6 workspace...")
    prepare_workspace(sy_params)

    print("[forward_v02B] Running MODFLOW 6...")
    success = run_mf6()
    if not success:
        sys.exit(1)

    print("[forward_v02B] Extracting simulated heads...")
    success = extract_sim_heads()
    if not success:
        sys.exit(1)

    elapsed = time.time() - t0
    ts_end = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    print(f"[forward_v02B] END: {ts_end} (elapsed: {elapsed:.0f}s = {elapsed/3600:.2f}h)")


if __name__ == "__main__":
    main()
