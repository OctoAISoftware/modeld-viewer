#!/usr/bin/env python3
"""
dry_run_walltime.py — Wall-Time Estimator for PEST++ v02B
==========================================================
Prints the estimated wall-time BEFORE launching the actual PEST++ run.
Does NOT execute any model. Paper estimate only.

Anchor: v02 transient measured ~4h19m (15,540s) per full forward on spark-ii.
"""

V02_WALL_SECONDS = 4 * 3600 + 19 * 60  # 15,540 s
V02_WALL_HOURS = V02_WALL_SECONDS / 3600  # 4.325 h
NUM_SP = 48
PER_SP_MIN = V02_WALL_SECONDS / NUM_SP / 60  # 5.4 min/SP

NPAR = 5
NOPTMAX = 5
N_LAMBDA = 5
N_SCALE_FAC = 3
NCORES = 20


def estimate():
    print("=" * 72)
    print(" WALL-TIME ESTIMATE: PEST++ v02B (GLM, 5 Sy, NOPTMAX=5)")
    print("=" * 72)
    print()
    print(" ANCHOR")
    print(" " + "-" * 70)
    print(f"   v02 full forward (48 SPs):   {V02_WALL_HOURS:.2f} h ({V02_WALL_SECONDS:,} s)")
    print(f"   Per stress period:           {PER_SP_MIN:.1f} min")
    print(f"   Machine:                     spark-ii (20 cores, 119 GB RAM)")
    print()
    print(" PEST++ GLM MECHANICS")
    print(" " + "-" * 70)
    print(f"   NOPTMAX (max iterations):    {NOPTMAX}")
    print(f"   NPAR (adjustable):           {NPAR}")
    print(f"   Lambdas tested per iter:     {N_LAMBDA}")
    print(f"   Lambda scale factors:        {N_SCALE_FAC}")
    print()
    print("   Per iteration, GLM computes:")
    print(f"     - Jacobian: {NPAR}+1 = {NPAR+1} forward runs (finite differences)")
    print(f"     - Lambda search: {N_LAMBDA} forward runs (upgrade testing)")
    print(f"     - Total per iter: {NPAR+1} + {N_LAMBDA} = {NPAR+1+N_LAMBDA} forwards")
    print()

    # Scenarios
    # Serial: all forwards sequential
    serial_forwards = NOPTMAX * (NPAR + 1 + N_LAMBDA)
    serial_hours = serial_forwards * V02_WALL_HOURS

    # Parallel Jacobian (6 runs on 20 cores = 1 batch), lambdas serial
    par_jac_hours = NOPTMAX * (V02_WALL_HOURS + N_LAMBDA * V02_WALL_HOURS)
    # Actually Jacobian can run in 1 batch (6 ≤ 20 cores)
    par_full_hours = NOPTMAX * (1 * V02_WALL_HOURS + N_LAMBDA * V02_WALL_HOURS)
    # If lambdas also parallelized (5 ≤ 20 cores)
    par_all_hours = NOPTMAX * (1 * V02_WALL_HOURS + 1 * V02_WALL_HOURS)

    # Best case: early convergence at iter 3
    best_iters = 3
    best_hours = best_iters * 2 * V02_WALL_HOURS

    print(" ESTIMATES")
    print(" " + "-" * 70)
    print(f" {'Scenario':<45} {'Fwds':>6} {'Hours':>8} {'Days':>6}")
    print(" " + "-" * 70)
    print(f" {'Serial (worst, no parallelism)':<45} "
          f"{serial_forwards:>6} {serial_hours:>8.1f} {serial_hours/24:>6.1f}")
    print(f" {'Parallel Jacobian only (6 at once)':<45} "
          f"{serial_forwards:>6} {par_jac_hours:>8.1f} {par_jac_hours/24:>6.1f}")
    print(f" {'Parallel Jacobian + lambdas (11 at once)':<45} "
          f"{serial_forwards:>6} {par_all_hours:>8.1f} {par_all_hours/24:>6.1f}")
    print(f" {'Best case (converges iter 3, full parallel)':<45} "
          f"{'~18':>6} {best_hours:>8.1f} {best_hours/24:>6.1f}")
    print(" " + "-" * 70)
    print()
    print(" BREAKDOWN (expected case: parallel Jacobian + lambdas)")
    print(" " + "-" * 70)
    print(f"   Iter 1: Jacobian batch ({NPAR+1} runs, 1 batch) = {V02_WALL_HOURS:.1f} h")
    print(f"           Lambda search ({N_LAMBDA} runs, 1 batch)  = {V02_WALL_HOURS:.1f} h")
    print(f"           Subtotal iter:                      = {2*V02_WALL_HOURS:.1f} h")
    print(f"   × {NOPTMAX} iterations                            = {NOPTMAX*2*V02_WALL_HOURS:.1f} h")
    print(f"   + Overhead (file I/O, workspace copy):       ≈ 1-2 h")
    print(f"   ─────────────────────────────────────────────────────")
    print(f"   ESTIMATED TOTAL (parallel, 20 cores):        ≈ {par_all_hours + 2:.0f} h "
          f"({(par_all_hours + 2)/24:.1f} days)")
    print()
    print(" RECOMMENDATION")
    print(" " + "-" * 70)
    print(f"   Realistic estimate: {par_all_hours:.0f}–{par_jac_hours:.0f} h "
          f"({par_all_hours/24:.1f}–{par_jac_hours/24:.1f} days)")
    print(f"   With early convergence: could finish in ~{best_hours:.0f} h ({best_hours/24:.1f} days)")
    print()
    print(" LAUNCH COMMAND")
    print(" " + "-" * 70)
    print("   # Activate environment")
    print('   eval "$(micromamba shell hook --shell bash)"')
    print("   micromamba activate pestpp_env")
    print()
    print("   # Generate/regenerate PEST++ files")
    print("   cd ~/modeld-flopy/autenried/Catchment_Autenried_flopy/V12_TRANSIENT_V02B_PEST")
    print("   python build_v02B_pest.py")
    print()
    print("   # Launch (use nohup for long run)")
    print("   nohup /home/suporte/micromamba/envs/pestpp_env/bin/pestpp-glm pst_v02B.pst "
          "> pest_v02B.log 2>&1 &")
    print("   echo $! > pest_pid.txt")
    print()
    print("   # Monitor")
    print("   tail -f pest_v02B.log")
    print("=" * 72)


if __name__ == "__main__":
    estimate()
