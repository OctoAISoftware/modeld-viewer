#!/bin/bash
cd "$(dirname "$0")"
/usr/bin/python3 forward_v02B.py
