"""
dry_run_walltime.py — Wall-time estimator for PEST++ v02B (paper estimate only)
=================================================================================
Does NOT run PEST++. Estimates based on measured v02 transient performance.

Anchor: v02 transient took 4h19m for 48 stress periods on spark-ii (20 cores).
"""

V02_WALL_SECONDS = 4 * 3600 + 19 * 60  # 4h19m = 15540s
V02_NUM_SP = 48
PER_SP_SECONDS = V02_WALL_SECONDS / V02_NUM_SP  # ~323.75 s/SP = ~5.4 min/SP
FULL_FORWARD_HOURS = V02_WALL_SECONDS / 3600  # 4.32 h

NPAR = 5
NOPTMAX = 5


def estimate():
    """
    PEST++ GLM forward-run estimation logic:
    -----------------------------------------
    For each iteration, GLM runs:
      - n_lambda trial runs (each is a full forward)
      - Jacobian upgrade: npar perturbation runs (each full forward)

    With default settings (5 lambdas, lambda_scale_fac=[0.75,1.0,1.1]):
      - lambda trials per iteration: n_lambda × n_scale_fac = 5 × 3 = 15
      - BUT pestpp-glm runs best lambda + upgrades = typically ~(npar+1) + lambda_trials

    Simplified estimate per iteration:
      - Jacobian: npar+1 forward runs (finite differences)
      - Lambda search: n_lambda forward runs
      - Total per iter ≈ (npar+1) + n_lambda = 6 + 5 = 11 forwards

    With 5 iterations:
      - First iter includes full Jacobian
      - Subsequent iters may reuse Jacobian (depends on settings)

    Conservative (no Jacobian reuse):
      forwards = NOPTMAX × (npar + 1 + n_lambda)

    Optimistic (Jacobian reuse after iter 1):
      forwards = (npar + 1 + n_lambda) + (NOPTMAX-1) × n_lambda
    """

    n_lambda = 5
    n_scale = 3

    # Best case: GLM with Jacobian reuse, parallel speedup
    best_forwards = (NPAR + 1) + NOPTMAX * n_lambda
    best_hours = best_forwards * FULL_FORWARD_HOURS

    # Expected case: full Jacobian each iteration, serial
    expected_forwards = NOPTMAX * (NPAR + 1 + n_lambda)
    expected_hours = expected_forwards * FULL_FORWARD_HOURS

    # Worst case: no parallelism, lambda_scale_fac triples trials
    worst_forwards = NOPTMAX * (NPAR + 1 + n_lambda * n_scale)
    worst_hours = worst_forwards * FULL_FORWARD_HOURS

    # With parallel (20 cores can parallelize npar+1=6 easily)
    par_speedup = min(NPAR + 1, 20)  # can parallelize Jacobian
    expected_parallel_hours = (
        NOPTMAX * (FULL_FORWARD_HOURS + n_lambda * FULL_FORWARD_HOURS / par_speedup)
    )

    print("=" * 70)
    print("WALL-TIME ESTIMATE: PEST++ v02B (GLM, 5 Sy parameters, NOPTMAX=5)")
    print("=" * 70)
    print()
    print("ANCHOR MEASUREMENT")
    print("-" * 70)
    print(f"  v02 transient full forward:  {FULL_FORWARD_HOURS:.2f} h ({V02_WALL_SECONDS}s)")
    print(f"  Stress periods:              {V02_NUM_SP}")
    print(f"  Per-SP time:                 {PER_SP_SECONDS:.0f} s ({PER_SP_SECONDS/60:.1f} min)")
    print(f"  Machine:                     spark-ii (20 cores, 119 GB RAM)")
    print()
    print("ESTIMATION PARAMETERS")
    print("-" * 70)
    print(f"  NOPTMAX:                     {NOPTMAX}")
    print(f"  NPAR (adjustable):           {NPAR}")
    print(f"  Lambda values:               {n_lambda}")
    print(f"  Lambda scale factors:        {n_scale}")
    print(f"  Forward model time:          {FULL_FORWARD_HOURS:.2f} h (v02 measured)")
    print()
    print("WALL-TIME ESTIMATE TABLE")
    print("-" * 70)
    print(f"{'Scenario':<35} {'Forwards':>10} {'Wall-time':>12} {'Days':>6}")
    print("-" * 70)
    print(
        f"{'Best case (Jacobian reuse)':<35} "
        f"{best_forwards:>10d} "
        f"{best_hours:>9.1f} h "
        f"{best_hours/24:>5.1f}"
    )
    print(
        f"{'Expected (serial, full Jacobian)':<35} "
        f"{expected_forwards:>10d} "
        f"{expected_hours:>9.1f} h "
        f"{expected_hours/24:>5.1f}"
    )
    print(
        f"{'Expected (parallel, 20 cores)':<35} "
        f"{'~' + str(expected_forwards):>10s} "
        f"{expected_parallel_hours:>9.1f} h "
        f"{expected_parallel_hours/24:>5.1f}"
    )
    print(
        f"{'Worst case (all scale_facs, serial)':<35} "
        f"{worst_forwards:>10d} "
        f"{worst_hours:>9.1f} h "
        f"{worst_hours/24:>5.1f}"
    )
    print("-" * 70)
    print()
    print("NOTES")
    print("-" * 70)
    print("  - 'Best case' assumes Jacobian computed once, reused for all iters")
    print("  - 'Expected (serial)' is the most likely scenario without parallelism")
    print("  - 'Expected (parallel)' assumes pestpp-glm uses all 20 cores for")
    print("    Jacobian perturbation runs (realistic with PEST++ parallel mode)")
    print("  - 'Worst case' multiplies lambda trials by all 3 scale factors")
    print("  - Each forward = full v02 transient (48 SPs, ~4h19m measured)")
    print("  - Actual time may be lower if early convergence (phi < threshold)")
    print("  - PEST++ GLM can parallelize Jacobian runs (npar+1 = 6 at once)")
    print()
    print("RECOMMENDATION")
    print("-" * 70)
    print(f"  Realistic estimate with 20-core parallelism: "
          f"~{expected_parallel_hours:.0f} h ({expected_parallel_hours/24:.1f} days)")
    print(f"  Plan for: {expected_hours:.0f} h serial / "
          f"{expected_parallel_hours:.0f} h parallel")
    print("=" * 70)


if __name__ == "__main__":
    estimate()
