# PEST++ v02B — Autenried Sy Optimization Kit

## Base Model (FROZEN)

The v02 calibrated transient model is the fixed base:
- **K (hydraulic conductivity)**: 9 Kxy + 9 Kz zones from PEST++ v12_optimized SS calibration (phi=35.95, 24 params, 10 iterations)
- **RCH (recharge)**: Monthly Thornthwaite, 6 spatial zones — frozen at v02 values
- **Ss (specific storage)**: Frozen at v02 calibrated values
- **WEL (pumping)**: Fixed schedule from v02 (pump pulses as-is)
- **CHD, GHB, OC**: All unchanged from v02

## What's Free (5 Parameters)

Only **Specific Yield (Sy)** in 5 zones is adjustable:

| Zone | Initial Sy | Bounds | Description |
|------|-----------|--------|-------------|
| Z3 | 0.18 | 0.05–0.35 | Pump zone (primary) |
| Z4 | 0.22 | 0.05–0.35 | Pump zone |
| Z5 | 0.15 | 0.05–0.35 | Nearby transition zone |
| Z6 | 0.20 | 0.05–0.35 | Pump zone |
| Z7 | 0.12 | 0.05–0.35 | Nearby alluvial zone |

Zones 1, 2, 8 (Sy = 0.03, 0.05, 0.10) remain fixed.

## Observations

- 7 AUT wells: AUT-01, AUT-02, AUT-03, AUT-05, AUT-06, AUT-07, AUT-08
- Daily heads, 48 stress periods
- ~3230 observation points total
- v02 calibration metrics: MAE 0.237 m, RMSE 0.299 m, bias +0.034 m, R=0.574

## How to Launch

```bash
# Activate environment with pestpp and flopy
eval "$(micromamba shell hook --shell bash)"
micromamba activate pestpp_env

# Option A: Single command (builds + runs)
cd ~/modeld-flopy/autenried/Catchment_Autenried_flopy/V12_TRANSIENT_V02/v02B_pest
python run_pest_v02B.py

# Option B: Build only (inspect before running)
python build_pest_v02B.py

# Option C: Direct PEST++ invocation (after build)
cd pest_run
/home/suporte/micromamba/envs/pestpp_env/bin/pestpp-glm v02B.pst
```

## Expected Wall-Time

Run `python dry_run_walltime.py` for the full estimate table.

Quick summary (based on v02 measured 4h19m per forward):
- **Best case (parallel, 20 cores)**: ~26 h (1.1 days)
- **Expected (serial)**: ~238 h (9.9 days)
- **Recommendation**: Use parallel mode on spark-ii → ~1-2 days

## PEST++ Mode

- **Engine**: pestpp-glm v5.2.25
- **NOPTMAX**: 5
- **Lambdas**: 0.1, 1, 10, 100, 1000
- **Scale factors**: 0.75, 1.0, 1.1

## Results (after run)

Look in `pest_run/` for:
- `v02B.iobj` — iteration objective function history
- `v02B.rei` — residuals (sim vs obs per observation)
- `v02B.par` — final optimized parameter values
- `v02B.rec` — run record (convergence, timing)
- `v02B.jco` — Jacobian matrix

## Changelog vs v03 Transient (abandoned)

The v03 transient was planned as a broader optimization (Sy + Ss + RCH free, 15+ parameters) but was abandoned because:
- Solver divergence at SP38 (Newton-Raphson failed to converge with too many free parameters affecting both storage and recharge simultaneously)
- Excessive wall-time (estimated 2+ weeks serial)
- Numerical instability in layers 3-5 where Ss and Sy interactions created oscillation

**v02B takes a conservative approach**: only Sy is free (5 zones, NOPTMAX 5), keeping the solver stable since K/RCH/Ss are all fixed at their calibrated values. This avoids the SP38 divergence entirely.
