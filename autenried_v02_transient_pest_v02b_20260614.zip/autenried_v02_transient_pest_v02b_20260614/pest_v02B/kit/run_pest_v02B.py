"""
run_pest_v02B.py — Single-shot runner for PEST++ GLM v02B Sy optimization
==========================================================================
Entry point: python run_pest_v02B.py

1. Calls build_pest_v02B.py if v02B.pst is missing
2. Invokes pestpp-glm on v02B.pst
3. Logs wall-time and iteration count
"""
import os
import sys
import time
import subprocess
from pathlib import Path
from datetime import datetime

SCRIPT_DIR = Path(__file__).parent
PEST_RUN_DIR = SCRIPT_DIR / "pest_run"
PST_FILE = PEST_RUN_DIR / "v02B.pst"
LOG_FILE = SCRIPT_DIR / "v02B_run.log"

PESTPP_GLM = "/home/suporte/micromamba/envs/pestpp_env/bin/pestpp-glm"
PESTPP_IES = "/home/suporte/micromamba/envs/pestpp_env/bin/pestpp-ies"


def log(msg):
    """Write to both stdout and log file."""
    ts = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    line = f"[{ts}] {msg}"
    print(line)
    with open(LOG_FILE, "a") as f:
        f.write(line + "\n")


def ensure_pst():
    """Build .pst if not present."""
    if PST_FILE.exists():
        log(f"v02B.pst already exists at {PST_FILE}")
        return

    log("v02B.pst not found — running builder...")
    sys.path.insert(0, str(SCRIPT_DIR))
    from build_pest_v02B import build
    build()

    if not PST_FILE.exists():
        log("ERROR: build_pest_v02B.py did not produce v02B.pst")
        sys.exit(1)


def find_executable():
    """Find pestpp-glm or fallback to pestpp-ies."""
    if os.path.isfile(PESTPP_GLM) and os.access(PESTPP_GLM, os.X_OK):
        return PESTPP_GLM, "GLM"
    if os.path.isfile(PESTPP_IES) and os.access(PESTPP_IES, os.X_OK):
        log("WARNING: pestpp-glm not found, falling back to pestpp-ies")
        return PESTPP_IES, "IES"
    raise FileNotFoundError(
        f"Neither pestpp-glm nor pestpp-ies found. "
        f"Checked: {PESTPP_GLM}, {PESTPP_IES}"
    )


def run():
    """Execute PEST++ and report results."""
    log("=" * 60)
    log("PEST++ v02B Runner — Autenried Sy Optimization")
    log("=" * 60)

    ensure_pst()

    exe, mode = find_executable()
    log(f"Executable: {exe} (mode: {mode})")
    log(f"Control file: {PST_FILE}")
    log(f"Working dir: {PEST_RUN_DIR}")

    log("")
    log("STARTING PEST++ RUN...")
    t0 = time.time()
    start_ts = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    log(f"  Start time: {start_ts}")

    proc = subprocess.run(
        [exe, "v02B.pst"],
        cwd=str(PEST_RUN_DIR),
        capture_output=True,
        text=True,
    )

    elapsed = time.time() - t0
    end_ts = datetime.now().strftime("%Y-%m-%d %H:%M:%S")

    log(f"  End time:   {end_ts}")
    log(f"  Wall-time:  {elapsed:.1f} s ({elapsed/3600:.2f} h)")
    log(f"  Exit code:  {proc.returncode}")

    pestpp_log = PEST_RUN_DIR / "v02B.rec"
    if pestpp_log.exists():
        with open(pestpp_log) as f:
            content = f.read()
        n_iters = content.count("starting iteration")
        log(f"  Iterations completed: {n_iters}")

    if proc.returncode != 0:
        log("  STATUS: FAILED")
        log(f"  STDERR: {proc.stderr[:500]}")
    else:
        log("  STATUS: SUCCESS")

    log("")
    log("Output files:")
    for ext in (".iobj", ".rei", ".par", ".rec", ".jco"):
        p = PEST_RUN_DIR / f"v02B{ext}"
        if p.exists():
            sz = p.stat().st_size / 1024
            log(f"  {p.name}: {sz:.1f} KB")

    log("=" * 60)
    log("RUN COMPLETE")
    log("=" * 60)

    return proc.returncode


if __name__ == "__main__":
    sys.exit(run())
