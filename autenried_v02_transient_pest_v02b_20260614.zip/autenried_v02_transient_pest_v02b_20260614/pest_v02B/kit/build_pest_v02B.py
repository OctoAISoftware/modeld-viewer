"""
build_pest_v02B.py — PEST++ GLM Template Builder for Autenried v02_B
=====================================================================
Takes the calibrated v02 transient model as the fixed base and opens
5 Sy zones (zones 3-7) for optimization. Everything else frozen.

Run: python build_pest_v02B.py
Output: v02B.pst + template/instruction files in ./pest_run/
"""
import os
import sys
import csv
import shutil
import numpy as np
from pathlib import Path

SCRIPT_DIR = Path(__file__).parent
V02_WORKSPACE = SCRIPT_DIR.parent / "mf6_workspace"
PEST_RUN_DIR = SCRIPT_DIR / "pest_run"

NOPTMAX = 5
NPHISTNO = 5
PESTPP_GLM_PATH = "/home/suporte/micromamba/envs/pestpp_env/bin/pestpp-glm"

SY_ZONE_MAP = {
    0.03: 1, 0.05: 2, 0.10: 8,
    0.12: 7, 0.15: 5, 0.18: 3,
    0.20: 6, 0.22: 4,
}
FREE_ZONES = [3, 4, 5, 6, 7]

PAR_TABLE = SCRIPT_DIR / "par_table.csv"
OBS_FILE = V02_WORKSPACE / "aut_heads.csv"
SIM_VS_OBS = SCRIPT_DIR.parent / "sim_vs_obs.csv"


def read_par_table():
    """Read parameter table CSV."""
    params = {}
    with open(PAR_TABLE) as f:
        reader = csv.DictReader(f)
        for row in reader:
            params[int(row["zone_id"])] = {
                "initial": float(row["initial_sy"]),
                "lower": float(row["lower_bound"]),
                "upper": float(row["upper_bound"]),
                "group": row["group"],
            }
    return params


def parse_sy_array():
    """Read Sy array from the .sto file, return (nlay, nrow, ncol, array)."""
    sto_path = V02_WORKSPACE / "gwf_tr_v02.sto"
    with open(sto_path) as f:
        lines = f.readlines()

    sy_start = None
    for i, line in enumerate(lines):
        if line.strip().startswith("sy") and "LAYERED" in lines[i].upper():
            sy_start = i + 1
            break

    if sy_start is None:
        raise RuntimeError("Cannot find 'sy LAYERED' section in .sto file")

    dis_path = V02_WORKSPACE / "gwf_tr_v02.dis"
    with open(dis_path) as f:
        dis_lines = f.readlines()

    nlay = nrow = ncol = None
    in_dims = False
    for line in dis_lines:
        stripped = line.strip()
        if stripped.startswith("BEGIN DIMENSIONS"):
            in_dims = True
            continue
        if stripped.startswith("END DIMENSIONS"):
            break
        if in_dims:
            parts = stripped.split()
            if parts[0].upper() == "NLAY":
                nlay = int(parts[1])
            elif parts[0].upper() == "NROW":
                nrow = int(parts[1])
            elif parts[0].upper() == "NCOL":
                ncol = int(parts[1])

    if None in (nlay, nrow, ncol):
        raise RuntimeError("Cannot read grid dimensions from .dis file")

    sy_array = np.zeros((nlay, nrow, ncol))
    idx = sy_start
    for lay in range(nlay):
        if "INTERNAL" not in lines[idx]:
            raise RuntimeError(f"Expected INTERNAL at line {idx}")
        idx += 1
        for row in range(nrow):
            vals = [float(x) for x in lines[idx].split()]
            sy_array[lay, row, :] = vals
            idx += 1

    return nlay, nrow, ncol, sy_array


def build_zone_array(sy_array):
    """Map Sy values to zone IDs."""
    zone_array = np.zeros_like(sy_array, dtype=int)
    for sy_val, zone_id in SY_ZONE_MAP.items():
        mask = np.isclose(sy_array, sy_val, atol=0.005)
        zone_array[mask] = zone_id
    return zone_array


def copy_model_files():
    """Copy v02 model to pest_run directory."""
    PEST_RUN_DIR.mkdir(parents=True, exist_ok=True)
    for f in V02_WORKSPACE.iterdir():
        if f.suffix in (".hds", ".cbc", ".lst", ".grb"):
            continue
        dst = PEST_RUN_DIR / f.name
        if not dst.exists():
            shutil.copy2(f, dst)


def write_tpl_file(nlay, nrow, ncol, zone_array, params):
    """Write PEST++ template file for the .sto file (Sy section only)."""
    tpl_path = PEST_RUN_DIR / "gwf_tr_v02.sto.tpl"
    sto_path = PEST_RUN_DIR / "gwf_tr_v02.sto"

    with open(sto_path) as f:
        lines = f.readlines()

    sy_start = None
    for i, line in enumerate(lines):
        if line.strip().startswith("sy") and "LAYERED" in line.upper():
            sy_start = i + 1
            break

    par_names = {z: f"sy_z{z:02d}" for z in FREE_ZONES}

    with open(tpl_path, "w") as tpl:
        tpl.write("ptf ~\n")
        for i, line in enumerate(lines):
            if i < sy_start:
                tpl.write(line)
                continue

            idx_offset = i - sy_start
            if idx_offset < 0:
                tpl.write(line)
                continue

            in_data = False
            current_lay = -1
            pos = sy_start
            for lay in range(nlay):
                if pos == i:
                    tpl.write(line)
                    in_data = False
                    break
                pos += 1
                row_start = pos
                row_end = pos + nrow
                if row_start <= i < row_end:
                    row_idx = i - row_start
                    vals = line.split()
                    new_vals = []
                    for col_idx, v in enumerate(vals):
                        z = zone_array[lay, row_idx, col_idx]
                        if z in FREE_ZONES:
                            pname = par_names[z]
                            new_vals.append(f"~  {pname:>12s}  ~")
                        else:
                            new_vals.append(v)
                    tpl.write("  ".join(new_vals) + "\n")
                    in_data = True
                    break
                pos = row_end

            if not in_data and i >= sy_start:
                tpl.write(line)

    return tpl_path, par_names


def write_ins_file():
    """Write PEST++ instruction file for observations."""
    ins_path = PEST_RUN_DIR / "aut_heads.csv.ins"
    obs_csv = PEST_RUN_DIR / "aut_heads.csv"

    well_names = ["aut01", "aut02", "aut03", "aut05", "aut06", "aut07", "aut08"]

    with open(ins_path, "w") as ins:
        ins.write("pif @\n")
        ins.write("l1\n")  # skip header

        if obs_csv.exists():
            with open(obs_csv) as f:
                header = f.readline()
                cols = [c.strip() for c in header.split(",")]
                nobs_cols = len([c for c in cols if c.lower() != "time"])

            with open(obs_csv) as f:
                f.readline()  # skip header
                obs_count = 0
                for line_num, line in enumerate(f, 1):
                    parts = line.strip().split(",")
                    if len(parts) < 2:
                        continue
                    ins.write("l1 ")
                    for i, col in enumerate(cols):
                        if col.lower() == "time":
                            continue
                        obs_name = f"h_{col}_{line_num:04d}"
                        if len(obs_name) > 20:
                            obs_name = obs_name[:20]
                        ins.write(f" !{obs_name}!")
                    ins.write("\n")
                    obs_count += 1
        else:
            obs_count = 0

    return ins_path, obs_count


def write_pst_file(par_names, params, obs_count):
    """Write PEST++ control file."""
    pst_path = PEST_RUN_DIR / "v02B.pst"
    npar = len(par_names)
    nobs = max(obs_count * 7, 1)

    with open(pst_path, "w") as pst:
        pst.write("pcf\n")
        pst.write("* control data\n")
        pst.write("restart estimation\n")
        pst.write(f"  {npar}  {nobs}  1  0  1\n")
        pst.write(f"  1  1  single  point  1  0  0\n")
        pst.write(f"  10.0  -3.0  0.3  0.03  10  999\n")
        pst.write(f"  10.0  10.0  0.001\n")
        pst.write(f"  0.1\n")
        pst.write(f"  {NOPTMAX}  0.005  4  4  0.005  4\n")
        pst.write(f"  0  0  0  0\n")

        pst.write("* parameter groups\n")
        pst.write("sy  relative  0.01  0.0  switch  2.0  parabolic\n")

        pst.write("* parameter data\n")
        for zone_id in sorted(par_names.keys()):
            pname = par_names[zone_id]
            p = params[zone_id]
            pst.write(
                f"{pname}  none  relative  {p['initial']:.4f}  "
                f"{p['lower']:.4f}  {p['upper']:.4f}  {p['group']}  1.0  0.0  1\n"
            )

        pst.write("* observation groups\n")
        pst.write("heads\n")

        pst.write("* observation data\n")
        for i in range(nobs):
            obs_name = f"obs_{i+1:05d}"
            pst.write(f"{obs_name}  0.0  1.0  heads\n")

        pst.write("* model command line\n")
        pst.write("mf6\n")

        pst.write("* model input/output\n")
        pst.write("gwf_tr_v02.sto.tpl  gwf_tr_v02.sto\n")
        pst.write("aut_heads.csv.ins  aut_heads.csv\n")

        pst.write("* prior information\n")

        pst.write("++#\n")
        pst.write(f"++pestpp_options(glm_num_reals(0))\n")
        pst.write(f"++pestpp_options(n_iter_base({NOPTMAX}))\n")
        pst.write(f"++pestpp_options(n_iter_super(0))\n")
        pst.write(f"++pestpp_options(lambdas(0.1,1,10,100,1000))\n")
        pst.write(f"++pestpp_options(lambda_scale_fac(0.75,1.0,1.1))\n")

    return pst_path


def build():
    """Main build entry point."""
    print("=" * 60)
    print("PEST++ v02B Builder — Autenried Sy Optimization")
    print("=" * 60)

    print("\n[1/6] Reading parameter table...")
    params = read_par_table()
    print(f"      {len(params)} zones to optimize: {sorted(params.keys())}")

    print("\n[2/6] Parsing Sy array from v02 .sto file...")
    nlay, nrow, ncol, sy_array = parse_sy_array()
    print(f"      Grid: {nlay} layers × {nrow} rows × {ncol} cols")

    print("\n[3/6] Building zone array...")
    zone_array = build_zone_array(sy_array)
    for z in FREE_ZONES:
        count = np.sum(zone_array == z)
        print(f"      Zone {z}: {count} cells, Sy={params[z]['initial']:.2f}")

    print("\n[4/6] Copying model files to pest_run/...")
    copy_model_files()

    print("\n[5/6] Writing template file...")
    tpl_path, par_names = write_tpl_file(nlay, nrow, ncol, zone_array, params)
    print(f"      Template: {tpl_path.name}")
    print(f"      Parameters: {list(par_names.values())}")

    print("\n[6/6] Writing instruction file and .pst...")
    ins_path, obs_count = write_ins_file()
    pst_path = write_pst_file(par_names, params, obs_count)
    print(f"      Instruction: {ins_path.name}")
    print(f"      Control file: {pst_path.name}")
    print(f"      NOPTMAX={NOPTMAX}, NPHISTNO={NPHISTNO}")
    print(f"      Observations: {obs_count * 7} ({obs_count} timesteps × 7 wells)")

    print("\n" + "=" * 60)
    print("BUILD COMPLETE")
    print(f"  PST file: {pst_path}")
    print(f"  Run dir:  {PEST_RUN_DIR}")
    print(f"  Invoke:   cd {PEST_RUN_DIR} && {PESTPP_GLM_PATH} v02B.pst")
    print("=" * 60)

    return pst_path


if __name__ == "__main__":
    build()
