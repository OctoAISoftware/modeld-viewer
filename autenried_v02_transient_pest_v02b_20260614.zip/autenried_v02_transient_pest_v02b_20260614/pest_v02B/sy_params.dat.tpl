ptf ~
# Sy parameter values for v02B PEST++ run
# zone_id  sy_value
2  ~        sy_z02~
3  ~        sy_z03~
4  ~        sy_z04~
5  ~        sy_z05~
6  ~        sy_z06~
