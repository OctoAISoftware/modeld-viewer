# Autenried v02B — PEST++ Sy Optimization Kit

## Overview

Focused PEST++ GLM calibration of 5 Specific Yield (Sy) zones using the v02 transient model as a frozen base. Only Sy varies; all other parameters are locked at their calibrated values.

## What is FROZEN

| Parameter | Source | Details |
|-----------|--------|---------|
| K (Kxy + Kz) | PEST++ V12 SS calibration | 9 Kxy + 9 Kz zones, 24 params total, phi=35.95, 10 iters |
| RCH (recharge) | Thornthwaite monthly | 6 spatial zones, monthly rates from xlsx |
| Pump schedule | AUT-03 derivative analysis | 16 transitions detected, rates -432 to -480 m³/d |
| Ss (specific storage) | v02 calibrated | 9 zones, literature-based with minor adjustments |
| CHD, GHB, IC | V12 steady-state | Boundary conditions from SS calibration |

## What is FREE (5 Sy Parameters)

| Zone | Parameter | Initial | Bounds | Role |
|------|-----------|---------|--------|------|
| Z2 | sy_z02 | 0.15 | 0.05–0.35 | Adjacent upstream — controls lateral drainage |
| Z3 | sy_z03 | 0.18 | 0.05–0.35 | Pump zone (primary, reduced from 0.22 in v02) |
| Z4 | sy_z04 | 0.22 | 0.05–0.35 | Pump zone (reduced from 0.28 in v02) |
| Z5 | sy_z05 | 0.10 | 0.03–0.30 | Surrounding deeper layers — vertical leakage |
| Z6 | sy_z06 | 0.20 | 0.05–0.35 | Pump zone (reduced from 0.25 in v02) |

**Zones NOT freed**: Z1 (thin surficial, 0.05), Z7/Z8 (distant alluvial), Z9 (bedrock, negligible Sy)

## PEST++ Settings

- **Engine**: pestpp-glm v5.2.25
- **NOPTMAX**: 5
- **Lambdas**: 0.1, 1.0, 10.0, 100.0, 1000.0
- **Lambda scale factors**: 0.75, 1.0, 1.1
- **Observation wells**: 7 AUT wells (AUT-01, -02, -03, -05, -06, -07, -08)
- **Observation points**: ~3,230 daily head measurements

## Expected Wall-Time

Based on v02 measured: **4h19m per full forward** (48 SPs on spark-ii, 20 cores)

| Scenario | Hours | Days |
|----------|-------|------|
| Serial (no parallelism) | ~238 h | 9.9 |
| Parallel Jacobian + lambdas | ~43 h | 1.8 |
| Best case (early convergence) | ~26 h | 1.1 |

**Realistic plan**: 2 days with 20-core parallelism.

Run `python dry_run_walltime.py` for the full breakdown.

## Launch Sequence

```bash
# 1. Check wall-time estimate
python dry_run_walltime.py

# 2. (Re)generate PEST++ files
python build_v02B_pest.py

# 3. Inspect pst_v02B.pst (check params, obs, template)

# 4. Launch
eval "$(micromamba shell hook --shell bash)"
micromamba activate pestpp_env
nohup /home/suporte/micromamba/envs/pestpp_env/bin/pestpp-glm pst_v02B.pst > pest_v02B.log 2>&1 &

# 5. Monitor
tail -f pest_v02B.log
```

## Success Criteria

- **MAE target**: < 0.237 m (v02 baseline)
- **Bias**: closer to 0 than v02's +0.034 m
- **R improvement**: better correlation than v02's R=0.574 on residual timeseries
- **No divergence**: solver converges on all 48 SPs (v03 failed at SP38 with too many free params)

## v02 Baseline Performance

- MAE: 0.237 m
- RMSE: 0.299 m
- Bias: +0.034 m
- R: 0.574
- Duration: 48 stress periods, ~4h19m wall-time
- Data points: 3,230 daily observations across 7 wells

## Kit Contents

| File | Purpose |
|------|---------|
| `build_v02B_pest.py` | Generates .pst, .tpl, .ins files |
| `forward_v02B.py` | MF6 forward runner (called by PEST++) |
| `pst_v02B.pst` | PEST++ control file (pre-generated) |
| `dry_run_walltime.py` | Wall-time estimate (no model run) |
| `run_v12_transient_v02.py` | Original v02 runner (reference, 930 lines) |
| `README_v02B.md` | This file |
| `sy_params.dat` | Initial Sy values for forward runner |
| `sy_params.dat.tpl` | PEST++ template for Sy injection |
| `sim_heads.csv.ins` | PEST++ instruction for reading outputs |

## Changelog vs v03 (abandoned)

The v03 transient attempted Sy + Ss + RCH optimization (15+ free parameters) but was abandoned due to:
- Newton-Raphson solver divergence at SP38
- Excessive wall-time (>2 weeks estimated serial)
- Parameter interaction oscillation between Ss and Sy in layers 3-5

**v02B** takes the conservative approach: only Sy is free, NOPTMAX=5, and the solver stays stable because K/RCH/Ss are all frozen.
