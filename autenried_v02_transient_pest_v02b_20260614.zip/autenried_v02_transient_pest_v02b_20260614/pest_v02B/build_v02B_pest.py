#!/usr/bin/env python3
"""
build_v02B_pest.py — PEST++ GLM Kit Builder for Autenried v02B Sy Optimization
================================================================================
Generates all PEST++ control/template/instruction files for estimating 5 Sy zones
with the v02 transient model as the fixed base.

Run: python build_v02B_pest.py
Output: pst_v02B.pst, *.tpl, *.ins files in this directory

PEST++ variant: pestpp-glm (same as the V12 SS calibration)
"""

import os
import sys
import csv
import shutil
import numpy as np
from pathlib import Path
from datetime import datetime

SCRIPT_DIR = Path(__file__).parent
V02_DIR = SCRIPT_DIR.parent / "V12_TRANSIENT_V02"
V02_MF6_WS = V02_DIR / "mf6_workspace"
OBS_DAILY = V02_DIR / "obs_daily.csv"
SIM_VS_OBS = V02_DIR / "sim_vs_obs.csv"

PESTPP_GLM = "/home/suporte/micromamba/envs/pestpp_env/bin/pestpp-glm"
MF6_EXE = "/home/suporte/micromamba/envs/mf6env/bin/mf6"

NOPTMAX = 5
NPAR = 5

# ── Zone selection rationale ──────────────────────────────────────────────────
# Z3, Z4, Z6: the three pump-area zones where Sy was manually adjusted in v02
#   (reduced 15-20% from literature to improve pump-response fit)
# Z2: adjacent zone immediately upstream of pump cone — controls lateral
#   drainage into the pump area
# Z5: zone surrounding the pump wells in deeper layers — controls vertical
#   leakage component during transient drawdown
#
# Zones NOT freed: Z1 (thin surficial), Z7/Z8 (distant alluvial, low sensitivity),
#   Z9 (bedrock, negligible storage)
# ──────────────────────────────────────────────────────────────────────────────

FREE_ZONES = {
    2: {"name": "sy_z02", "initial": 0.15, "lower": 0.05, "upper": 0.35},
    3: {"name": "sy_z03", "initial": 0.18, "lower": 0.05, "upper": 0.35},
    4: {"name": "sy_z04", "initial": 0.22, "lower": 0.05, "upper": 0.35},
    5: {"name": "sy_z05", "initial": 0.10, "lower": 0.03, "upper": 0.30},
    6: {"name": "sy_z06", "initial": 0.20, "lower": 0.05, "upper": 0.35},
}

FROZEN_SY = {1: 0.05, 7: 0.10, 8: 0.12, 9: 0.03}

ALL_ZONES_SY = {**{z: p["initial"] for z, p in FREE_ZONES.items()}, **FROZEN_SY}

WELLS = ["AUT-01", "AUT-02", "AUT-03", "AUT-05", "AUT-06", "AUT-07", "AUT-08"]


def load_observations():
    """Load obs_daily.csv and return list of (date, well, head, sim_day)."""
    obs = []
    with open(OBS_DAILY) as f:
        reader = csv.DictReader(f)
        for row in reader:
            obs.append({
                "date": row["date"],
                "well": row["well"],
                "head_m": float(row["head_m"]),
                "sim_day": int(row["sim_day"]),
            })
    return obs


def compute_weights(obs):
    """
    Assign observation weights. Strategy matches v02:
    - Weight = 1.0 for all valid observations
    - Weight = 0.0 during identified dry/pump-off recovery windows where
      the model systematically underperforms (first 5 days after pump restart)
    """
    weighted = []
    for o in obs:
        w = 1.0
        weighted.append({**o, "weight": w})
    return weighted


def write_tpl_file():
    """
    Write template file for forward_v02B.py parameter input.
    The forward runner reads sy_params.dat which contains zone:value pairs.
    """
    tpl_path = SCRIPT_DIR / "sy_params.dat.tpl"
    with open(tpl_path, "w") as f:
        f.write("ptf ~\n")
        f.write("# Sy parameter values for v02B PEST++ run\n")
        f.write("# zone_id  sy_value\n")
        for zone_id in sorted(FREE_ZONES.keys()):
            pname = FREE_ZONES[zone_id]["name"]
            f.write(f"{zone_id}  ~{pname:>14s}~\n")
    print(f"  Written: {tpl_path.name}")
    return tpl_path


def write_ins_file(obs_weighted):
    """Write instruction file to read simulated heads from forward_v02B output."""
    ins_path = SCRIPT_DIR / "sim_heads.csv.ins"
    with open(ins_path, "w") as f:
        f.write("pif @\n")
        f.write("l1\n")  # skip CSV header
        for i, o in enumerate(obs_weighted):
            if o["weight"] > 0:
                obs_name = f"h{o['well'].replace('-','').lower()}_{o['sim_day']:04d}"
                if len(obs_name) > 20:
                    obs_name = obs_name[:20]
                f.write(f"l1 !{obs_name}!\n")
            else:
                f.write("l1\n")
    print(f"  Written: {ins_path.name}")
    return ins_path


def write_pst_file(obs_weighted):
    """Write the PEST++ control file."""
    pst_path = SCRIPT_DIR / "pst_v02B.pst"

    active_obs = [o for o in obs_weighted if o["weight"] > 0]
    nobs = len(active_obs)

    with open(pst_path, "w") as f:
        f.write("pcf\n")
        f.write("* control data\n")
        f.write("restart estimation\n")
        f.write(f"  {NPAR}  {nobs}  1  0  1\n")
        f.write(f"  1  1  single  point  1  0  0\n")
        f.write(f"  10.0  -3.0  0.3  0.03  10  999\n")
        f.write(f"  10.0  10.0  0.001\n")
        f.write(f"  0.1\n")
        f.write(f"  {NOPTMAX}  0.005  4  4  0.005  4\n")
        f.write(f"  0  0  0  0\n")

        f.write("* parameter groups\n")
        f.write("sy  relative  0.01  0.0  switch  2.0  parabolic\n")

        f.write("* parameter data\n")
        for zone_id in sorted(FREE_ZONES.keys()):
            p = FREE_ZONES[zone_id]
            f.write(
                f"{p['name']}  none  relative  {p['initial']:.4f}  "
                f"{p['lower']:.4f}  {p['upper']:.4f}  sy  1.0  0.0  1\n"
            )

        f.write("* observation groups\n")
        for well in WELLS:
            grp = well.replace("-", "").lower()
            f.write(f"{grp}\n")

        f.write("* observation data\n")
        for i, o in enumerate(active_obs):
            obs_name = f"h{o['well'].replace('-','').lower()}_{o['sim_day']:04d}"
            if len(obs_name) > 20:
                obs_name = obs_name[:20]
            grp = o["well"].replace("-", "").lower()
            f.write(f"{obs_name}  {o['head_m']:.4f}  {o['weight']:.2f}  {grp}\n")

        f.write("* model command line\n")
        f.write("python forward_v02B.py\n")

        f.write("* model input/output\n")
        f.write("sy_params.dat.tpl  sy_params.dat\n")
        f.write("sim_heads.csv.ins  sim_heads.csv\n")

        f.write("* prior information\n")

        f.write("\n")
        f.write("++#\n")
        f.write(f"++n_iter_base({NOPTMAX})\n")
        f.write(f"++n_iter_super(0)\n")
        f.write(f"++lambdas(0.1,1.0,10.0,100.0,1000.0)\n")
        f.write(f"++lambda_scale_fac(0.75,1.0,1.1)\n")
        f.write(f"++glm_num_reals(0)\n")
        f.write(f"++overdue_giveup_fac(2.0)\n")

    print(f"  Written: {pst_path.name}")
    print(f"    NPAR={NPAR}, NOBS={nobs}, NOPTMAX={NOPTMAX}")
    return pst_path


def write_initial_params():
    """Write initial sy_params.dat for dry runs."""
    dat_path = SCRIPT_DIR / "sy_params.dat"
    with open(dat_path, "w") as f:
        f.write("# Sy parameter values for v02B PEST++ run\n")
        f.write("# zone_id  sy_value\n")
        for zone_id in sorted(FREE_ZONES.keys()):
            f.write(f"{zone_id}  {FREE_ZONES[zone_id]['initial']:.4f}\n")
    print(f"  Written: {dat_path.name}")


def build():
    """Main build entry point."""
    print("=" * 70)
    print("PEST++ v02B Kit Builder — Autenried Sy Optimization")
    print(f"  Date: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}")
    print(f"  PEST++ variant: pestpp-glm v5.2.25")
    print("=" * 70)

    print("\n[1/5] Loading observations from v02...")
    obs = load_observations()
    print(f"  Loaded {len(obs)} observations from {len(WELLS)} wells")

    print("\n[2/5] Computing observation weights...")
    obs_weighted = compute_weights(obs)
    n_active = sum(1 for o in obs_weighted if o["weight"] > 0)
    print(f"  Active observations: {n_active}/{len(obs_weighted)}")

    print("\n[3/5] Writing template file...")
    write_tpl_file()

    print("\n[4/5] Writing instruction file...")
    write_ins_file(obs_weighted)

    print("\n[5/5] Writing control file (pst_v02B.pst)...")
    write_pst_file(obs_weighted)
    write_initial_params()

    print("\n" + "=" * 70)
    print("BUILD COMPLETE")
    print(f"  Control file: pst_v02B.pst")
    print(f"  Template:     sy_params.dat.tpl → sy_params.dat")
    print(f"  Instruction:  sim_heads.csv.ins ← sim_heads.csv")
    print(f"  Forward cmd:  python forward_v02B.py")
    print(f"  Launch:       {PESTPP_GLM} pst_v02B.pst")
    print("=" * 70)


if __name__ == "__main__":
    build()
