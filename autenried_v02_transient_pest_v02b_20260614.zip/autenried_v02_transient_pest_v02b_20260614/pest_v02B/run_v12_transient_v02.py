#!/usr/bin/env python3
"""
Autenried V12 — Transient v02

Changes from v01:
  - Monthly transient recharge from transient_rch_autenried_catchment.xlsx
  - Refined pump schedule from AUT-03 derivative analysis (15 transitions)
  - Adjusted Sy in zones 3/4/6 (reduced 15-20% for pump sensitivity)
  - Stress periods split at monthly recharge + pump ON/OFF boundaries (~35 SPs)
  - K from PEST++ SS calibration (unchanged)
  - IC from V12 steady-state .HDS (unchanged)

Recharge parameterization ready for future PEST++ transient calibration
(multiplier per zone, applied on top of Thornthwaite-based monthly rates).
"""

import os
import sys
import time
from datetime import datetime, timedelta
from bisect import bisect_right
from pathlib import Path

import numpy as np
import pandas as pd
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import matplotlib.dates as mdates

MF6_EXE = "/home/suporte/micromamba/envs/mf6env/bin/mf6"

BASE_DIR = Path("/home/suporte/modeld-flopy/autenried")
DATA_DIR = BASE_DIR / "Catchment_Autenried_flopy"
PEST_BASE = DATA_DIR / "v12_pest_base"
PEST_WS = DATA_DIR / "pest_v12_optimized_run"
PAR_FILE = PEST_WS / "catchment.8.par"
SS_HDS = DATA_DIR / "V12_PEST_BEST_FORWARD" / "mf6_workspace" / "gwf_v12_best.hds"
RCH_XLSX = BASE_DIR / "transient_rch_autenried_catchment.xlsx"

OUT_DIR = DATA_DIR / "V12_TRANSIENT_V02"
PLOTS_DIR = OUT_DIR / "plots"
MODEL_WS = OUT_DIR / "mf6_workspace"

OBS_CSV = BASE_DIR / "obs_transient_pruned.csv"

CM_S_TO_M_D = 864.0
NLAY = 19
XORIGIN = 590300.0
YORIGIN = 5357815.0

PUMP_WELL_X = 592665.80
PUMP_WELL_Y = 5356985.00
PUMP_WELL_SCREEN_TOP = 492.2
PUMP_WELL_SCREEN_BOT = 487.1

SIM_START = datetime(2024, 9, 26)
SIM_YEARS = 3
SIM_END = SIM_START + timedelta(days=round(SIM_YEARS * 365.25))

AUT_WELLS = {
    "AUT-01": {"x": 592648.32, "y": 5356973.22, "screen_elev": 489.5},
    "AUT-02": {"x": 592654.17, "y": 5356965.34, "screen_elev": 491.5},
    "AUT-03": {"x": 592672.64, "y": 5356977.38, "screen_elev": 492.0},
    "AUT-05": {"x": 592652.69, "y": 5356975.21, "screen_elev": 492.8},
    "AUT-06": {"x": 592649.29, "y": 5356980.78, "screen_elev": 493.0},
    "AUT-07": {"x": 592651.62, "y": 5356981.79, "screen_elev": 492.0},
    "AUT-08": {"x": 592654.45, "y": 5356983.2, "screen_elev": 491.8},
}

# ── Pump transitions from AUT-03 derivative analysis ─────────
# Each entry: from this date onward, pump rate changes to this value.
PUMP_SCHEDULE = [
    (datetime(2024, 9, 26), -480.0, "Phase 1: initial test"),
    (datetime(2024, 10, 8), 0.0, "Recovery"),
    (datetime(2024, 11, 6), -480.0, "Phase 2: restart -480"),
    (datetime(2025, 1, 26), 0.0, "Recovery / seasonality"),
    (datetime(2025, 2, 16), -432.0, "Long-term -432"),
    (datetime(2025, 4, 26), 0.0, "Recovery"),
    (datetime(2025, 5, 19), -432.0, "Detected: pump ON May-Jun"),
    (datetime(2025, 6, 10), 0.0, "Recovery (summer)"),
    (datetime(2025, 8, 19), -432.0, "Detected: pump ON Aug-Sep"),
    (datetime(2025, 9, 11), 0.0, "Short recovery"),
    (datetime(2025, 9, 16), -432.0, "Detected: pump ON Sep-Oct"),
    (datetime(2025, 10, 1), 0.0, "Recovery pre-Phase 3"),
    (datetime(2025, 11, 9), -432.0, "Phase 3 start"),
    (datetime(2025, 11, 14), 0.0, "Intermittent OFF"),
    (datetime(2026, 1, 5), -432.0, "Phase 3 resumed"),
    (datetime(2026, 2, 10), 0.0, "Post-experiment recovery"),
]

# ── Literature Sy / Ss by K zone (v02 adjusted) ──────────────
ZONE_SY = {
    1: 0.05,
    2: 0.15,
    3: 0.18,   # was 0.22 — reduced for pump sensitivity
    4: 0.22,   # was 0.28
    5: 0.10,
    6: 0.20,   # was 0.25
    7: 0.10,
    8: 0.12,
    9: 0.03,
}
ZONE_SS = {
    1: 5.0e-4,
    2: 5.0e-5,
    3: 1.0e-5,
    4: 5.0e-6,
    5: 2.0e-4,
    6: 5.0e-6,
    7: 2.0e-4,
    8: 1.0e-4,
    9: 1.0e-3,
}


# ── Recharge loading ─────────────────────────────────────────

def load_monthly_recharge():
    """Load monthly recharge from xlsx and extend to cover full simulation."""
    df = pd.read_excel(RCH_XLSX, header=None)
    rows = df.iloc[17:48]

    rch_months = []
    for _, row in rows.iterrows():
        date = pd.to_datetime(row.iloc[0])
        ndays = pd.to_numeric(row.iloc[2], errors="coerce")
        zones = {}
        for zi, col_idx in enumerate([5, 6, 7, 8, 9, 10], start=1):
            v = pd.to_numeric(row.iloc[col_idx], errors="coerce")
            zones[zi] = float(v) if pd.notna(v) else 0.0
        if pd.notna(ndays) and pd.notna(date):
            rch_months.append((date.to_pydatetime(), int(ndays), zones))

    last_date = rch_months[-1][0]
    if last_date < SIM_END:
        year_start = rch_months[-12][0]
        for entry_date, ndays, zones in rch_months[-12:]:
            new_date = entry_date.replace(year=entry_date.year + 1)
            if new_date > last_date and new_date < SIM_END + timedelta(days=60):
                rch_months.append((new_date, ndays, dict(zones)))

    rch_months.sort(key=lambda x: x[0])
    return rch_months


# ── Stress period generation ─────────────────────────────────

def generate_stress_periods(rch_months):
    """Merge pump transitions + monthly recharge boundaries into stress periods."""
    transitions = set()
    transitions.add(SIM_START)
    transitions.add(SIM_END)

    for date, _, _ in PUMP_SCHEDULE:
        if SIM_START <= date < SIM_END:
            transitions.add(date)

    for date, _, _ in rch_months:
        if SIM_START <= date < SIM_END:
            transitions.add(date)

    transitions = sorted(transitions)

    pump_dates = [d for d, _, _ in PUMP_SCHEDULE]
    pump_rates = [r for _, r, _ in PUMP_SCHEDULE]
    pump_labels = [l for _, _, l in PUMP_SCHEDULE]
    rch_dates = [d for d, _, _ in rch_months]
    rch_entries = [(nd, zr) for _, nd, zr in rch_months]

    stress_periods = []
    for i in range(len(transitions) - 1):
        sp_start = transitions[i]
        sp_end = transitions[i + 1]
        dur = (sp_end - sp_start).days
        if dur <= 0:
            continue

        pidx = bisect_right(pump_dates, sp_start) - 1
        pump_rate = pump_rates[pidx] if pidx >= 0 else 0.0
        pump_label = pump_labels[pidx] if pidx >= 0 else "OFF"

        ridx = bisect_right(rch_dates, sp_start) - 1
        if ridx >= 0 and ridx < len(rch_entries):
            rch_ndays, rch_zones = rch_entries[ridx]
            rch_md = {}
            for z, v_mm in rch_zones.items():
                rch_md[z] = v_mm / 1000.0 / max(rch_ndays, 1)
        else:
            rch_md = {z: 0.0 for z in range(1, 7)}

        stress_periods.append({
            "start": sp_start,
            "end": sp_end,
            "dur": dur,
            "pump_rate": pump_rate,
            "pump_label": pump_label,
            "rch_md": rch_md,
        })

    return stress_periods


# ── Helper functions ─────────────────────────────────────────

def parse_pest_par(par_path):
    params = {}
    with open(par_path) as f:
        for line in f:
            line = line.strip()
            if not line or line.startswith("single") or line.startswith("#"):
                continue
            parts = line.split()
            if len(parts) >= 2:
                params[parts[0].strip()] = float(parts[1])
    return params


def build_x_y_edges(delr, delc):
    x_edges = np.zeros(len(delr) + 1)
    x_edges[0] = XORIGIN
    x_edges[1:] = XORIGIN + np.cumsum(delr)
    y_edges = np.zeros(len(delc) + 1)
    y_edges[0] = YORIGIN
    y_edges[1:] = YORIGIN - np.cumsum(delc)
    return x_edges, y_edges


def xy_to_rowcol(x, y, x_edges, y_edges):
    col = int(np.clip(np.searchsorted(x_edges, x) - 1, 0, len(x_edges) - 2))
    row = int(np.clip(np.searchsorted(-y_edges, -y) - 1, 0, len(y_edges) - 2))
    return row, col


def find_layer_for_screen(screen_elev, row, col, top, botm, idomain):
    for k in range(NLAY):
        if idomain[k, row, col] <= 0:
            continue
        cell_top = float(top[row, col]) if k == 0 else float(botm[k - 1, row, col])
        cell_bot = float(botm[k, row, col])
        if cell_bot <= screen_elev <= cell_top:
            return k
    min_dist = float("inf")
    best_k = 0
    for k in range(NLAY):
        if idomain[k, row, col] <= 0:
            continue
        cell_top = float(top[row, col]) if k == 0 else float(botm[k - 1, row, col])
        cell_bot = float(botm[k, row, col])
        cell_mid = (cell_top + cell_bot) / 2.0
        dist = abs(screen_elev - cell_mid)
        if dist < min_dist:
            min_dist = dist
            best_k = k
    return best_k


def load_daily_obs():
    df = pd.read_csv(OBS_CSV)
    df["timestamp"] = pd.to_datetime(df["timestamp"])
    df["date"] = df["timestamp"].dt.date
    daily = df.groupby(["date", "well"])["head_m_asl"].mean().reset_index()
    daily.columns = ["date", "well", "head_m"]
    daily["date"] = pd.to_datetime(daily["date"])
    daily["sim_day"] = (daily["date"] - pd.Timestamp(SIM_START)).dt.days
    return daily


# ── Model builder ────────────────────────────────────────────

def build_transient_model(params, stress_periods, calib=None):
    """Build MF6 transient model.

    calib: optional dict from PEST v03 — multipliers applied on top of v02 defaults:
      rch_z1..rch_z6 — per-zone factor on monthly recharge (each stress period).
      sy_m1..sy_m9, ss_m1..ss_m9 — factors on literature Sy/Ss by K zone.
      ghb_mult — factor on all GHB conductances (SW package proxy).
    """
    import flopy

    print("  Loading base arrays...")
    top = np.load(PEST_BASE / "top.npy")
    botm = np.load(PEST_BASE / "botm.npy")
    idomain = np.load(PEST_BASE / "idomain.npy")
    delr = np.load(PEST_BASE / "delr.npy")
    delc = np.load(PEST_BASE / "delc.npy")
    k_zone_array = np.load(PEST_BASE / "k_zone_array.npy")
    rch_zone_array = np.load(PEST_BASE / "rch_zone_array.npy")
    md_kx = np.load(PEST_BASE / "md_kx.npy")
    md_ky = np.load(PEST_BASE / "md_ky.npy")
    md_kz = np.load(PEST_BASE / "md_kz.npy")
    chd_raw = np.load(PEST_BASE / "chd_spd.npy", allow_pickle=True)
    ghb_raw = np.load(PEST_BASE / "ghb_spd.npy", allow_pickle=True)
    k_zones_vmp = np.load(PEST_BASE / "k_zones_vmp.npy", allow_pickle=True).item()
    zone_k_bounds = np.load(PEST_BASE / "zone_k_bounds.npy", allow_pickle=True).item()

    nrow, ncol = top.shape
    x_edges, y_edges = build_x_y_edges(delr, delc)
    print(f"  Grid: {NLAY}L x {nrow}R x {ncol}C")

    # ── K arrays (PEST SS calibrated) ──
    print("  Applying calibrated K parameters...")
    Kx = np.zeros((NLAY, nrow, ncol))
    Ky = np.zeros_like(Kx)
    Kz = np.zeros_like(Kx)

    for zid in k_zones_vmp:
        zid_int = int(zid)
        kx_base, ky_base, kz_base = k_zones_vmp[zid]
        kxy_val = params.get(f"kxy_z{zid_int}", kx_base) * CM_S_TO_M_D
        kz_val = params.get(f"kz_z{zid_int}", kz_base) * CM_S_TO_M_D
        mask = k_zone_array == zid_int
        Kx[mask] = kxy_val
        Ky[mask] = kxy_val
        Kz[mask] = kz_val

    md_valid = np.isfinite(md_kx)
    Kx[md_valid] = md_kx[md_valid]
    Ky[md_valid] = md_ky[md_valid]
    Kz[md_valid] = md_kz[md_valid]

    for zid_str in zone_k_bounds:
        zid_int = int(zid_str)
        kmin_cms, kmax_cms = zone_k_bounds[zid_str]
        kmin_md = kmin_cms * CM_S_TO_M_D
        kmax_md = kmax_cms * CM_S_TO_M_D
        mask = (k_zone_array == zid_int) & (idomain > 0)
        Kx[mask] = np.clip(Kx[mask], kmin_md, kmax_md)
        Ky[mask] = np.clip(Ky[mask], kmin_md, kmax_md)
        Kz[mask] = np.clip(Kz[mask], kmin_md * 0.1, kmax_md)

    inactive = idomain <= 0
    Kx[inactive] = 1.0
    Ky[inactive] = 1.0
    Kz[inactive] = 0.1

    # ── Per-SP recharge arrays ──
    print("  Building per-SP recharge arrays (transient, monthly)...")
    rch_spd = {}
    for sp_idx, sp in enumerate(stress_periods):
        rch_array = np.zeros((nrow, ncol), dtype=float)
        for zone_id in range(1, 7):
            mask = rch_zone_array == zone_id
            rate = sp["rch_md"].get(zone_id, 0.0)
            if calib:
                rate *= float(calib.get(f"rch_z{zone_id}", 1.0))
            rch_array[mask] = rate
        rch_spd[sp_idx] = rch_array

    # ── BCs (same for all SPs) ──
    chd_records = [(tuple(int(v) for v in r[0]), float(r[1])) for r in chd_raw]
    ghb_mult = float(calib.get("ghb_mult", 1.0)) if calib else 1.0
    ghb_records = [
        (tuple(int(v) for v in r[0]), float(r[1]), float(r[2]) * ghb_mult)
        for r in ghb_raw
    ]

    # ── Storage arrays ──
    print("  Building STO arrays (v02 adjusted Sy)...")
    sy_arr = np.ones((NLAY, nrow, ncol)) * 0.10
    ss_arr = np.ones((NLAY, nrow, ncol)) * 1.0e-4
    for zid in range(1, 10):
        mask = k_zone_array == zid
        sy_v = ZONE_SY[zid]
        ss_v = ZONE_SS[zid]
        if calib:
            sy_v *= float(calib.get(f"sy_m{zid}", 1.0))
            ss_v *= float(calib.get(f"ss_m{zid}", 1.0))
        sy_arr[mask] = sy_v
        ss_arr[mask] = ss_v
    sy_arr[inactive] = 0.10
    ss_arr[inactive] = 1.0e-4

    # ── Well layer distribution ──
    row_w, col_w = xy_to_rowcol(PUMP_WELL_X, PUMP_WELL_Y, x_edges, y_edges)
    screen_len = PUMP_WELL_SCREEN_TOP - PUMP_WELL_SCREEN_BOT
    well_layers = []
    for k in range(NLAY):
        if idomain[k, row_w, col_w] <= 0:
            continue
        cell_top = float(top[row_w, col_w]) if k == 0 else float(botm[k - 1, row_w, col_w])
        cell_bot = float(botm[k, row_w, col_w])
        if cell_bot >= PUMP_WELL_SCREEN_TOP or cell_top <= PUMP_WELL_SCREEN_BOT:
            continue
        overlap = min(cell_top, PUMP_WELL_SCREEN_TOP) - max(cell_bot, PUMP_WELL_SCREEN_BOT)
        if overlap > 0 and screen_len > 0:
            well_layers.append((k, row_w, col_w, overlap / screen_len))

    print(f"  Pumping well: row={row_w}, col={col_w}, layers={[wl[0] for wl in well_layers]}")

    # ── WEL per stress period ──
    n_sp = len(stress_periods)
    wel_spd = {}
    for sp_idx, sp in enumerate(stress_periods):
        rate = sp["pump_rate"]
        if rate != 0:
            wel_spd[sp_idx] = [
                ((k, r, c), float(rate * frac))
                for k, r, c, frac in well_layers
            ]
        else:
            wel_spd[sp_idx] = []

    # ── AUT observation wells ──
    print("  Resolving AUT observation wells...")
    aut_lrc = {}
    for wname, winfo in AUT_WELLS.items():
        r, c = xy_to_rowcol(winfo["x"], winfo["y"], x_edges, y_edges)
        lay = find_layer_for_screen(winfo["screen_elev"], r, c, top, botm, idomain)
        aut_lrc[wname] = (lay, r, c)
        cell_top_v = float(top[r, c]) if lay == 0 else float(botm[lay - 1, r, c])
        cell_bot_v = float(botm[lay, r, c])
        print(f"    {wname}: L{lay} R{r} C{c}  screen={winfo['screen_elev']:.1f}m "
              f" cell=[{cell_bot_v:.1f}, {cell_top_v:.1f}]")

    # ── Initial heads from SS .HDS ──
    print(f"  Loading SS heads from {SS_HDS.name}...")
    ss_hds = flopy.utils.HeadFile(str(SS_HDS))
    strt = ss_hds.get_data()
    strt[idomain <= 0] = 0.0
    print(f"  SS head range (active): [{strt[idomain > 0].min():.2f}, "
          f"{strt[idomain > 0].max():.2f}] m")

    # ── TDIS ──
    total_days = sum(sp["dur"] for sp in stress_periods)
    print(f"\n  Simulation: {SIM_START.date()} -> "
          f"{(SIM_START + timedelta(days=total_days)).date()} "
          f"({total_days} days, {n_sp} SPs)")

    perioddata = []
    for sp in stress_periods:
        perioddata.append((float(sp["dur"]), sp["dur"], 1.0))

    # ── Write MF6 model ──
    print("\n  Writing MF6 transient v02 simulation...")
    MODEL_WS.mkdir(parents=True, exist_ok=True)

    sim = flopy.mf6.MFSimulation(
        sim_name="v12_transient_v02", sim_ws=str(MODEL_WS), exe_name=MF6_EXE,
    )
    flopy.mf6.ModflowTdis(sim, time_units="DAYS", nper=n_sp, perioddata=perioddata)

    gwf = flopy.mf6.ModflowGwf(
        sim, modelname="gwf_tr_v02", save_flows=True,
        newtonoptions="NEWTON UNDER_RELAXATION",
    )

    flopy.mf6.ModflowIms(
        sim,
        print_option="SUMMARY",
        complexity="COMPLEX",
        linear_acceleration="BICGSTAB",
        outer_maximum=500,
        inner_maximum=400,
        outer_dvclose=1.0e-3,
        inner_dvclose=1.0e-4,
        rcloserecord=[1.0e-1, "STRICT"],
        under_relaxation="DBD",
        under_relaxation_gamma=0.0,
        under_relaxation_theta=0.7,
        under_relaxation_kappa=0.08,
        backtracking_number=25,
        backtracking_tolerance=2.0,
        backtracking_reduction_factor=0.2,
        backtracking_residual_limit=5.0e-4,
    )

    flopy.mf6.ModflowGwfdis(
        gwf,
        nlay=NLAY, nrow=nrow, ncol=ncol,
        delr=delr, delc=delc, top=top, botm=botm, idomain=idomain,
        xorigin=XORIGIN, yorigin=YORIGIN,
    )

    flopy.mf6.ModflowGwfic(gwf, strt=strt)

    icelltype = np.ones((NLAY, nrow, ncol), dtype=int)
    for rec in chd_records:
        ci = rec[0]
        icelltype[ci[0], ci[1], ci[2]] = 0
    for rec in ghb_records:
        ci = rec[0]
        icelltype[ci[0], ci[1], ci[2]] = 0
    n_confined_bc = int((icelltype == 0).sum())
    print(f"  icelltype: {int((icelltype == 1).sum())} convertible, "
          f"{n_confined_bc} confined (BC cells)")

    flopy.mf6.ModflowGwfnpf(
        gwf,
        icelltype=icelltype,
        k=Kx, k22=Ky, k33=Kz,
        save_specific_discharge=True,
    )

    flopy.mf6.ModflowGwfsto(
        gwf,
        iconvert=icelltype,
        ss=ss_arr,
        sy=sy_arr,
        steady_state={0: False},
        transient={0: True},
    )

    if chd_records:
        flopy.mf6.ModflowGwfchd(gwf, stress_period_data=chd_records)
    if ghb_records:
        flopy.mf6.ModflowGwfghb(gwf, stress_period_data=ghb_records)

    flopy.mf6.ModflowGwfwel(
        gwf,
        stress_period_data=wel_spd,
        print_input=True,
        print_flows=True,
        save_flows=True,
        auto_flow_reduce=0.1,
    )

    flopy.mf6.ModflowGwfrcha(gwf, recharge=rch_spd, fixed_cell=False)

    obs_name = "aut_heads.csv"
    obs_list = []
    for wname, (lay, r, c) in aut_lrc.items():
        safe_name = wname.replace("-", "").lower()
        obs_list.append((safe_name, "HEAD", (lay, r, c)))

    flopy.mf6.ModflowUtlobs(
        gwf, digits=10, print_input=True,
        continuous={obs_name: obs_list},
    )

    flopy.mf6.ModflowGwfoc(
        gwf,
        head_filerecord="gwf_tr_v02.hds",
        budget_filerecord="gwf_tr_v02.cbc",
        saverecord=[("HEAD", "LAST"), ("BUDGET", "LAST")],
        printrecord=[("HEAD", "LAST")],
    )

    sim.write_simulation()
    print("  Model files written.")

    return sim, gwf, aut_lrc, total_days


def run_model(sim):
    print("\n  Running MF6 transient v02...")
    t0 = time.time()
    success, buff = sim.run_simulation(silent=False)
    elapsed = time.time() - t0
    status = "CONVERGED" if success else "FAILED"
    print(f"\n  MF6 {status} in {elapsed:.1f}s ({elapsed / 60:.1f} min)")
    if not success:
        for line in buff[-50:]:
            print(f"    {line}")
    return success, elapsed


# ── Post-processing ──────────────────────────────────────────

def load_sim_obs(model_ws, total_days):
    obs_path = model_ws / "gwf_tr_v02.obs.aut_heads.csv"
    if not obs_path.exists():
        obs_path = model_ws / "aut_heads.csv"
    if not obs_path.exists():
        candidates = list(model_ws.glob("*aut*head*.csv"))
        if candidates:
            obs_path = candidates[0]
        else:
            print(f"  WARNING: OBS output not found in {model_ws}")
            return None

    print(f"  Loading simulated obs from {obs_path.name}...")
    sim_df = pd.read_csv(obs_path)
    sim_df.columns = [c.strip().lower() for c in sim_df.columns]

    if "time" in sim_df.columns:
        sim_df["date"] = sim_df["time"].apply(
            lambda t: SIM_START + timedelta(days=float(t))
        )
    return sim_df


def build_comparison(sim_df, obs_daily):
    well_map = {
        "aut01": "AUT-01", "aut02": "AUT-02", "aut03": "AUT-03",
        "aut05": "AUT-05", "aut06": "AUT-06", "aut07": "AUT-07",
        "aut08": "AUT-08",
    }

    records = []
    for sim_col, obs_well in well_map.items():
        if sim_col not in sim_df.columns:
            continue
        obs_w = obs_daily[obs_daily["well"] == obs_well].copy()
        obs_w = obs_w.set_index("date")

        for _, row in sim_df.iterrows():
            sim_date = row["date"]
            sim_head = row[sim_col]
            obs_head = np.nan
            if sim_date in obs_w.index:
                obs_head = obs_w.loc[sim_date, "head_m"]
                if isinstance(obs_head, pd.Series):
                    obs_head = obs_head.iloc[0]

            records.append({
                "date": sim_date,
                "well": obs_well,
                "sim_head": sim_head,
                "obs_head": obs_head,
                "residual": sim_head - obs_head if not np.isnan(obs_head) else np.nan,
            })

    return pd.DataFrame(records)


# ── Plotting ─────────────────────────────────────────────────

WELL_COLORS = {
    "AUT-01": "#E53935", "AUT-02": "#1E88E5", "AUT-03": "#43A047",
    "AUT-05": "#FB8C00", "AUT-06": "#8E24AA", "AUT-07": "#00ACC1",
    "AUT-08": "#6D4C41",
}


def _add_pump_shading(ax, stress_periods):
    for sp in stress_periods:
        if sp["pump_rate"] != 0:
            ax.axvspan(sp["start"], sp["end"], alpha=0.08, color="red", zorder=0)


def plot_individual_timeseries(comp_df, obs_daily, stress_periods):
    wells = sorted(comp_df["well"].unique())
    n_wells = len(wells)

    fig, axes = plt.subplots(n_wells, 1, figsize=(18, 3.2 * n_wells), sharex=True)
    if n_wells == 1:
        axes = [axes]

    for ax, well in zip(axes, wells):
        color = WELL_COLORS.get(well, "gray")

        sim_w = comp_df[comp_df["well"] == well].sort_values("date")
        ax.plot(sim_w["date"], sim_w["sim_head"], "-", color=color, linewidth=1.0,
                alpha=0.8, label="Simulated")

        obs_w = obs_daily[obs_daily["well"] == well].sort_values("date")
        ax.plot(obs_w["date"], obs_w["head_m"], ".", color="black", markersize=1.5,
                alpha=0.5, label="Observed (daily)")

        _add_pump_shading(ax, stress_periods)

        ax.set_ylabel("Head [m asl]", fontsize=9)
        ax.set_title(well, fontsize=10, fontweight="bold", loc="left")
        ax.legend(fontsize=7, loc="upper right")
        ax.grid(True, alpha=0.3)
        ax.xaxis.set_major_formatter(mdates.DateFormatter("%b %Y"))
        ax.xaxis.set_major_locator(mdates.MonthLocator(interval=3))

    axes[-1].set_xlabel("Date", fontsize=10)
    fig.suptitle(
        "V12 Transient v02 — Simulated vs Observed (AUT wells, daily)\n"
        "Red shading = pumping ON | Monthly transient recharge",
        fontsize=13, fontweight="bold",
    )
    fig.autofmt_xdate(rotation=30)
    fig.tight_layout()
    fig.savefig(PLOTS_DIR / "01_timeseries_individual.png", dpi=200, bbox_inches="tight")
    plt.close(fig)
    print("    01_timeseries_individual.png")


def plot_overlay_timeseries(comp_df, obs_daily, stress_periods):
    fig, axes = plt.subplots(3, 1, figsize=(18, 12), sharex=True,
                              gridspec_kw={"height_ratios": [3, 1, 1]})

    ax_head, ax_pump, ax_rch = axes

    wells = sorted(comp_df["well"].unique())
    for well in wells:
        color = WELL_COLORS.get(well, "gray")
        sim_w = comp_df[comp_df["well"] == well].sort_values("date")
        obs_w = obs_daily[obs_daily["well"] == well].sort_values("date")
        ax_head.plot(sim_w["date"], sim_w["sim_head"], "-", color=color,
                     linewidth=1.0, alpha=0.8, label=f"{well} sim")
        ax_head.plot(obs_w["date"], obs_w["head_m"], ".", color=color,
                     markersize=1.5, alpha=0.4)

    _add_pump_shading(ax_head, stress_periods)
    ax_head.set_ylabel("Head [m asl]", fontsize=11)
    ax_head.set_title(
        "V12 Transient v02 — All AUT Wells (solid=sim, dots=obs)",
        fontsize=13, fontweight="bold",
    )
    ax_head.legend(fontsize=7, ncol=4, loc="upper right")
    ax_head.grid(True, alpha=0.3)

    for sp in stress_periods:
        ax_pump.fill_between(
            [sp["start"], sp["end"]], [sp["pump_rate"], sp["pump_rate"]],
            color="steelblue", alpha=0.7, step="post",
        )
    ax_pump.axhline(0, color="black", linewidth=0.5)
    ax_pump.set_ylabel("Pump [m³/d]", fontsize=10)
    ax_pump.grid(True, alpha=0.3)

    for sp in stress_periods:
        z4_rate = sp["rch_md"].get(4, 0.0) * 1000 * 365.25
        ax_rch.fill_between(
            [sp["start"], sp["end"]], [z4_rate, z4_rate],
            color="forestgreen", alpha=0.5, step="post",
        )
    ax_rch.set_ylabel("RCH Z4 [mm/yr eq]", fontsize=10)
    ax_rch.set_xlabel("Date", fontsize=10)
    ax_rch.grid(True, alpha=0.3)
    ax_rch.xaxis.set_major_formatter(mdates.DateFormatter("%b %Y"))
    ax_rch.xaxis.set_major_locator(mdates.MonthLocator(interval=3))

    fig.autofmt_xdate(rotation=30)
    fig.tight_layout()
    fig.savefig(PLOTS_DIR / "02_timeseries_overlay.png", dpi=200, bbox_inches="tight")
    plt.close(fig)
    print("    02_timeseries_overlay.png")


def plot_residuals_timeseries(comp_df):
    valid = comp_df.dropna(subset=["residual"])
    if valid.empty:
        return

    wells = sorted(valid["well"].unique())
    n_wells = len(wells)

    fig, axes = plt.subplots(n_wells, 1, figsize=(18, 2.5 * n_wells), sharex=True)
    if n_wells == 1:
        axes = [axes]

    for ax, well in zip(axes, wells):
        color = WELL_COLORS.get(well, "gray")
        w = valid[valid["well"] == well].sort_values("date")
        ax.plot(w["date"], w["residual"], ".", color=color, markersize=2, alpha=0.5)
        ax.axhline(0, color="black", linewidth=0.5)
        ax.axhline(1, color="red", linewidth=0.5, linestyle="--", alpha=0.5)
        ax.axhline(-1, color="red", linewidth=0.5, linestyle="--", alpha=0.5)
        mae = w["residual"].abs().mean()
        rmse = np.sqrt((w["residual"] ** 2).mean())
        ax.set_title(f"{well}  (MAE={mae:.2f}m, RMSE={rmse:.2f}m)",
                     fontsize=9, fontweight="bold", loc="left")
        ax.set_ylabel("Res [m]", fontsize=8)
        ax.grid(True, alpha=0.3)

    axes[-1].set_xlabel("Date")
    fig.suptitle("V12 Transient v02 — Residuals (sim - obs)", fontsize=13, fontweight="bold")
    fig.autofmt_xdate(rotation=30)
    fig.tight_layout()
    fig.savefig(PLOTS_DIR / "03_residuals_timeseries.png", dpi=200, bbox_inches="tight")
    plt.close(fig)
    print("    03_residuals_timeseries.png")


def plot_scatter(comp_df):
    valid = comp_df.dropna(subset=["residual"])
    if valid.empty:
        return

    fig, ax = plt.subplots(figsize=(9, 9))
    wells = sorted(valid["well"].unique())
    for well in wells:
        color = WELL_COLORS.get(well, "gray")
        w = valid[valid["well"] == well]
        ax.scatter(w["obs_head"], w["sim_head"], s=4, alpha=0.3, color=color, label=well)

    all_obs = valid["obs_head"]
    all_sim = valid["sim_head"]
    vmin = min(all_obs.min(), all_sim.min()) - 0.5
    vmax = max(all_obs.max(), all_sim.max()) + 0.5
    ax.plot([vmin, vmax], [vmin, vmax], "k-", linewidth=1.5, label="1:1")

    mae = valid["residual"].abs().mean()
    rmse = np.sqrt((valid["residual"] ** 2).mean())
    bias = valid["residual"].mean()
    r = np.corrcoef(all_obs, all_sim)[0, 1]
    ax.text(
        0.03, 0.97,
        f"MAE  = {mae:.3f} m\nRMSE = {rmse:.3f} m\nBias = {bias:+.3f} m\n"
        f"R    = {r:.4f}\nN    = {len(valid)}",
        transform=ax.transAxes, fontsize=10, va="top",
        fontfamily="monospace",
        bbox=dict(boxstyle="round", facecolor="wheat", alpha=0.8),
    )

    ax.set_xlabel("Observed Head [m]", fontsize=12)
    ax.set_ylabel("Simulated Head [m]", fontsize=12)
    ax.set_title("V12 Transient v02 — Sim vs Obs (all AUT wells)",
                 fontsize=13, fontweight="bold")
    ax.set_aspect("equal")
    ax.set_xlim(vmin, vmax)
    ax.set_ylim(vmin, vmax)
    ax.legend(fontsize=8, markerscale=3)
    ax.grid(True, alpha=0.3)
    fig.tight_layout()
    fig.savefig(PLOTS_DIR / "04_scatter_sim_vs_obs.png", dpi=200, bbox_inches="tight")
    plt.close(fig)
    print("    04_scatter_sim_vs_obs.png")


def write_comparison_csv(comp_df):
    out_path = OUT_DIR / "sim_vs_obs.csv"
    comp_df.to_csv(out_path, index=False, float_format="%.4f")
    print(f"    {out_path.name}")


# ── Main ─────────────────────────────────────────────────────

def main():
    t0 = time.time()

    print("=" * 70)
    print("  Autenried V12 — TRANSIENT v02")
    print("  Monthly transient recharge + refined pump schedule + Sy adjusted")
    print("=" * 70)

    OUT_DIR.mkdir(parents=True, exist_ok=True)
    PLOTS_DIR.mkdir(parents=True, exist_ok=True)

    # [1] Load recharge data
    print("\n[1] Loading monthly recharge from xlsx...")
    rch_months = load_monthly_recharge()
    print(f"    {len(rch_months)} monthly recharge entries loaded")
    print(f"    Range: {rch_months[0][0].date()} to {rch_months[-1][0].date()}")

    # [2] Generate stress periods
    print("\n[2] Generating merged stress periods...")
    stress_periods = generate_stress_periods(rch_months)
    total_days = sum(sp["dur"] for sp in stress_periods)
    n_pump_on = sum(1 for sp in stress_periods if sp["pump_rate"] != 0)
    print(f"    {len(stress_periods)} stress periods ({total_days} days)")
    print(f"    {n_pump_on} with pump ON, "
          f"{len(stress_periods) - n_pump_on} with pump OFF")

    for i, sp in enumerate(stress_periods):
        rch_z4 = sp["rch_md"].get(4, 0) * 1000 * 365.25
        pump_str = f"{sp['pump_rate']:>8.1f}" if sp["pump_rate"] != 0 else "     OFF"
        print(f"    SP {i:2d}: {sp['start'].date()} +{sp['dur']:3d}d  "
              f"pump={pump_str}  rch_z4={rch_z4:6.0f}mm/yr  {sp['pump_label']}")

    # [3] Load PEST K parameters (SS calibrated — K only, not RCH multipliers)
    print("\n[3] Reading calibrated K parameters...")
    params = parse_pest_par(PAR_FILE)
    rch_keys = [k for k in params if k.startswith("rch_")]
    for k in rch_keys:
        del params[k]
    print(f"    {len(params)} K parameters loaded (RCH multipliers excluded for v02)")

    # [4] Load observations
    print("\n[4] Loading daily observations...")
    obs_daily = load_daily_obs()
    print(f"    {len(obs_daily)} daily obs points, "
          f"{obs_daily['well'].nunique()} wells")
    obs_daily.to_csv(OUT_DIR / "obs_daily.csv", index=False, float_format="%.4f")

    # [5] Build model
    print("\n[5] Building transient v02 model...")
    sim, gwf, aut_lrc, total_days = build_transient_model(params, stress_periods)

    # [6] Run
    print("\n[6] Running simulation...")
    success, run_time = run_model(sim)
    if not success:
        print("FATAL: MF6 did not converge!")
        sys.exit(1)

    # [7] Post-process
    print("\n[7] Loading simulated observations...")
    sim_df = load_sim_obs(MODEL_WS, total_days)
    if sim_df is None:
        print("FATAL: Could not load OBS output!")
        sys.exit(1)
    print(f"    {len(sim_df)} time steps loaded")

    # [8] Build comparison
    print("\n[8] Building sim vs obs comparison...")
    comp_df = build_comparison(sim_df, obs_daily)
    valid = comp_df.dropna(subset=["residual"])
    if len(valid) > 0:
        mae = valid["residual"].abs().mean()
        rmse = np.sqrt((valid["residual"] ** 2).mean())
        bias = valid["residual"].mean()
        r = np.corrcoef(valid["obs_head"], valid["sim_head"])[0, 1]
        print(f"    Matched obs: {len(valid)} points")
        print(f"    MAE  = {mae:.3f} m")
        print(f"    RMSE = {rmse:.3f} m")
        print(f"    Bias = {bias:+.3f} m")
        print(f"    R    = {r:.4f}")

    # [9] Plots
    print("\n[9] Generating plots...")
    plot_individual_timeseries(comp_df, obs_daily, stress_periods)
    plot_overlay_timeseries(comp_df, obs_daily, stress_periods)
    plot_residuals_timeseries(comp_df)
    plot_scatter(comp_df)

    # [10] CSV output
    print("\n[10] Writing comparison CSV...")
    write_comparison_csv(comp_df)

    # [11] Write stress period summary
    sp_summary = OUT_DIR / "stress_period_summary.csv"
    with open(sp_summary, "w") as f:
        f.write("sp,start,end,dur_days,pump_m3d,rch_z1_md,rch_z4_md,rch_z6_md,label\n")
        for i, sp in enumerate(stress_periods):
            f.write(f"{i},{sp['start'].date()},{sp['end'].date()},{sp['dur']},"
                    f"{sp['pump_rate']:.1f},"
                    f"{sp['rch_md'].get(1,0):.6e},"
                    f"{sp['rch_md'].get(4,0):.6e},"
                    f"{sp['rch_md'].get(6,0):.6e},"
                    f"{sp['pump_label']}\n")
    print(f"    {sp_summary.name}")

    elapsed = time.time() - t0
    print(f"\n{'=' * 70}")
    print(f"  DONE in {elapsed:.1f}s ({elapsed / 60:.1f} min)")
    print(f"  Output: {OUT_DIR}")
    if len(valid) > 0:
        print(f"  MAE={mae:.3f}m | RMSE={rmse:.3f}m | Bias={bias:+.3f}m | R={r:.4f}")
    print(f"{'=' * 70}")


if __name__ == "__main__":
    main()
