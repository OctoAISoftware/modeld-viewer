#!/bin/bash
cd "$(dirname "$0")"
export PATH="/home/suporte/micromamba/envs/pestpp_env/bin:/home/suporte/micromamba/envs/mf6env/bin:/usr/bin:$PATH"
export MF6_EXE="/home/suporte/micromamba/envs/mf6env/bin/mf6"
PESTPP=/home/suporte/micromamba/envs/pestpp_env/bin/pestpp-glm
echo "[$(date)] Starting pestpp-glm v02B run"
echo "[$(date)] Executable: $PESTPP"
echo "[$(date)] Working dir: $(pwd)"
echo "[$(date)] Python: $(which python3)"
$PESTPP pst_v02B.pst
echo "[$(date)] pestpp-glm exited with code $?"
