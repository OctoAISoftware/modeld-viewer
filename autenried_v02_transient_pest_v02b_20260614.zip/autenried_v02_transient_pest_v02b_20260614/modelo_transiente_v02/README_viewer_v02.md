# Autenried V12 Transient v02 — Visualizador 3D

Arquivo único: **`v02_3d_viewer.html`** — abre em qualquer navegador (Chrome recomendado),
sem internet e sem configuração. Plotly embutido no próprio HTML.

## Como navegar
- **Arrastar** = girar · **scroll** = zoom · **botão direito + arrastar** = pan.
- Botões no topo trocam a visão. Slider embaixo varre os **48 períodos de estresse** (em dias).

## As 3 visões (botões no topo)
1. **Head** — nuvem de pontos das células ativas, colorida pela carga hidráulica (colormap *viridis*).
   O slider de tempo troca a carga período a período.
2. **K zones** — mesmas células coloridas pela condutividade hidráulica Kx (13 zonas distintas da
   calibração SS). A barra de cor lista o valor de Kx (m/d) de cada zona. Overlay GHB ligado.
3. **Drawdown** — rebaixamento = carga inicial SS − carga transiente (colormap divergente RdBu,
   centrado em 0). O slider mostra a evolução do rebaixamento. Overlay GHB ligado.

- **Terreno** (superfície cinza) = topo do modelo, sempre visível ao fundo.
- **GHB cells** (losangos pretos) = células de contorno General-Head, sobrepostas nas visões K e Drawdown.

## Dados / contexto de calibração
- Modelo: MODFLOW 6, grid **19 camadas × 403 linhas × 577 colunas**, ~2,1 milhões de células ativas.
- 48 períodos de estresse (diário), recarga transiente mensal (Thornthwaite).
- Fonte: saída transiente v02 **já calibrada** (`gwf_tr_v02.hds`), zonas K da calibração SS,
  pacote GHB do modelo. **Não** é a saída do PEST++ v02 B (esse roda em separado).
- History match v02: **MAE 0,237 m · RMSE 0,299 m · viés +0,034 m · R 0,574**
  (3.230 pontos diários em 7 poços AUT).

## Notas técnicas
- A nuvem é decimada para ~16.000 células (amostra uniforme) para o navegador ficar fluido;
  GHB mostrado com ~4.000 pontos.
- Exagero vertical aplicado (×11) para as 19 camadas ficarem visíveis contra a extensão horizontal (km).
- Gerado por `modflow_3d_html_viewer.py` (leitura read-only via flopy; nenhum arquivo do modelo alterado).
