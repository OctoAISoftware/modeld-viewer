"""
Autenried V12 TRANSIENT v02 — self-contained 3D HTML viewer.

Single entrypoint: reads the MF6 grid / NPF / IC / GHB and the transient .hds,
decimates the active cells to a browser-friendly point cloud, and writes ONE
self-contained HTML (Plotly via CDN) with three view tabs:

  1) Head      — hydraulic head (end of transient, SP48 / t=1096 d), Viridis,
                 with a gray terrain (DEM top) backdrop.
  2) K zones   — calibrated steady-state Kx zones, distinct colors, legend with
                 the Kx value of each zone, GHB cells marked as black diamonds.
  3) Drawdown  — steady-state minus transient head, Rainbow, GHB overlay.

Mirrors the structure of the Model D `modeld-viewer` (Plotly gl3d, decimated
active cells, dark theme, rotatable scene). Read-only on the model files; does
NOT touch the concurrent v02B PEST++ run.
"""

import os
os.environ.setdefault("OMP_NUM_THREADS", "1")
os.environ.setdefault("OPENBLAS_NUM_THREADS", "1")
os.environ.setdefault("MKL_NUM_THREADS", "1")

from pathlib import Path
import numpy as np
import plotly.graph_objects as go
import flopy

ROOT = Path("/home/suporte/modeld-flopy/autenried/Catchment_Autenried_flopy/V12_TRANSIENT_V02")
WS = ROOT / "mf6_workspace"
OUT = ROOT / "viewer" / "autenried_v02_viewer.html"

TARGET_POINTS = 28000      # decimation target for the active-cell cloud
GHB_TARGET = 1500          # decimated GHB diamonds
DEM_STRIDE = 4             # terrain surface downsample
SEED = 42

# History-match stats (from sim_vs_obs.csv summary, supplied with the task)
HM = dict(mae=0.237, rmse=0.299, bias=0.034, r=0.574, npts=3230, nwells=7)

print("=" * 64)
print("Autenried V12 TRANSIENT v02 — 3D viewer build")
print("=" * 64)

# ----------------------------------------------------------------------------
# Load grid + packages (read-only, single intermediate-free pass)
# ----------------------------------------------------------------------------
print("Loading grid ...", flush=True)
grb = flopy.mf6.utils.MfGrdFile(str(WS / "gwf_tr_v02.dis.grb"))
mg = grb.modelgrid
nlay, nrow, ncol = mg.nlay, mg.nrow, mg.ncol
print(f"  grid: {nlay} layers x {nrow} rows x {ncol} cols", flush=True)

print("Loading dis/npf/ic/ghb ...", flush=True)
sim = flopy.mf6.MFSimulation.load(
    sim_ws=str(WS), load_only=["dis", "npf", "ic", "ghb"], verbosity_level=0
)
gwf = sim.get_model()
idomain = gwf.dis.idomain.array
act = idomain > 0
nactive = int(act.sum())
k = np.asarray(gwf.npf.k.array, dtype=float)      # Kx in m/d
strt = np.asarray(gwf.ic.strt.array, dtype=float)  # steady-state IC heads
top = np.asarray(gwf.dis.top.array, dtype=float)
botm = np.asarray(gwf.dis.botm.array, dtype=float)
print(f"  active cells: {nactive:,}", flush=True)

print("Loading transient heads (last stress period) ...", flush=True)
hf = flopy.utils.HeadFile(str(WS / "gwf_tr_v02.hds"))
times = hf.get_times()
nsp = len(times)
head = np.asarray(hf.get_data(totim=times[-1]), dtype=float)
drawdown = strt - head            # SS - transient; +ve = water level dropped

# ----------------------------------------------------------------------------
# Cell-center geometry
# ----------------------------------------------------------------------------
xc = mg.xcellcenters                      # (nrow, ncol)
yc = mg.ycellcenters
celltop = np.empty_like(botm)
celltop[0] = top
celltop[1:] = botm[:-1]
zc = 0.5 * (celltop + botm)               # (nlay, nrow, ncol)

Xc = np.broadcast_to(xc, k.shape)
Yc = np.broadcast_to(yc, k.shape)
Lc = np.broadcast_to(np.arange(nlay)[:, None, None], k.shape)

# Flatten active cells
ai = np.where(act)
xa = Xc[ai].astype(float)
ya = Yc[ai].astype(float)
za = zc[ai].astype(float)
la = Lc[ai].astype(int)
head_a = head[ai]
k_a = k[ai]
draw_a = drawdown[ai]

# Normalize horizontal coords to local meters (nicer hover, smaller numbers)
x0, y0 = float(xa.min()), float(ya.min())
xa_l = xa - x0
ya_l = ya - y0

# ----------------------------------------------------------------------------
# Decimate active cells, stratified per layer so every layer is represented
# ----------------------------------------------------------------------------
rng = np.random.default_rng(SEED)
keep = np.zeros(xa.shape[0], dtype=bool)
frac = min(1.0, TARGET_POINTS / xa.shape[0])
for L in range(nlay):
    idx = np.where(la == L)[0]
    if idx.size == 0:
        continue
    nkeep = max(1, int(round(idx.size * frac)))
    sel = rng.choice(idx, size=min(nkeep, idx.size), replace=False)
    keep[sel] = True
ksub = np.where(keep)[0]
print(f"  decimated cloud: {ksub.size:,} points (target {TARGET_POINTS:,})", flush=True)

sx = np.round(xa_l[ksub], 1)
sy = np.round(ya_l[ksub], 1)
sz = np.round(za[ksub], 2)
s_head = np.round(head_a[ksub], 3)
s_k = k_a[ksub]
s_draw = np.round(draw_a[ksub], 3)
s_lay = (la[ksub] + 1).astype(int)

# ----------------------------------------------------------------------------
# K zones from the calibrated NPF field (distinct Kx values)
# ----------------------------------------------------------------------------
kuniq = np.unique(np.round(k_a, 6))
nz = kuniq.size
zone_of = {float(v): i for i, v in enumerate(kuniq)}
s_zone = np.array([zone_of[float(round(v, 6))] for v in s_k], dtype=int)
print(f"  K zones (distinct calibrated Kx): {nz}", flush=True)

# A distinct color per zone (sample a perceptually varied palette)
import plotly.express as px
base_pal = (px.colors.qualitative.Dark24 + px.colors.qualitative.Light24
            + px.colors.qualitative.Alphabet)
zone_colors = [base_pal[i % len(base_pal)] for i in range(nz)]

# ----------------------------------------------------------------------------
# GHB cells -> diamonds (decimated)
# ----------------------------------------------------------------------------
ghb = gwf.ghb.stress_period_data.get_data(0)
gcells = np.array([c for c in ghb["cellid"]])       # (n, 3): lay,row,col
gl, gr, gcc = gcells[:, 0], gcells[:, 1], gcells[:, 2]
gx = xc[gr, gcc] - x0
gy = yc[gr, gcc] - y0
gz = zc[gl, gr, gcc]
if gx.size > GHB_TARGET:
    gsel = rng.choice(gx.size, size=GHB_TARGET, replace=False)
else:
    gsel = np.arange(gx.size)
gx, gy, gz = np.round(gx[gsel], 1), np.round(gy[gsel], 1), np.round(gz[gsel], 2)
print(f"  GHB diamonds: {gx.size:,} (of {gcells.shape[0]:,} total)", flush=True)

# ----------------------------------------------------------------------------
# Terrain (DEM = model top), downsampled, gray
# ----------------------------------------------------------------------------
ttop = top[::DEM_STRIDE, ::DEM_STRIDE]
txx = (xc[::DEM_STRIDE, ::DEM_STRIDE] - x0)
tyy = (yc[::DEM_STRIDE, ::DEM_STRIDE] - y0)
ttop = np.where(np.isfinite(ttop), ttop, np.nan)
print(f"  terrain mesh: {ttop.shape[0]}x{ttop.shape[1]}", flush=True)

# ----------------------------------------------------------------------------
# Build figure
# ----------------------------------------------------------------------------
print("Building figure ...", flush=True)
fig = go.Figure()
traces = []  # (name_group) bookkeeping

# --- terrain (group: head) ---
fig.add_trace(go.Surface(
    x=np.round(txx, 1), y=np.round(tyy, 1), z=np.round(ttop, 2),
    surfacecolor=np.round(ttop, 2),
    colorscale="Greys", reversescale=True,
    opacity=0.45, showscale=False, name="Terreno (DEM topo)",
    hovertemplate="DEM topo<br>z=%{z:.1f} m<extra></extra>",
    visible=True,
))
IDX_TERRAIN = 0

# --- head cloud (group: head) ---
fig.add_trace(go.Scatter3d(
    x=sx, y=sy, z=sz, mode="markers",
    marker=dict(size=2.2, color=s_head, colorscale="Viridis",
                colorbar=dict(title="Carga (m)", x=1.02, len=0.55, y=0.5),
                showscale=True, opacity=0.85),
    customdata=np.stack([s_lay, s_head], axis=-1),
    hovertemplate=("x=%{x:.0f} m  y=%{y:.0f} m<br>"
                   "Camada %{customdata[0]}<br>"
                   "Elev=%{z:.1f} m<br>Carga=%{customdata[1]:.2f} m<extra></extra>"),
    name="Carga hidráulica", showlegend=False, visible=True,
))
IDX_HEAD = 1

# --- drawdown cloud (group: drawdown) ---
fig.add_trace(go.Scatter3d(
    x=sx, y=sy, z=sz, mode="markers",
    marker=dict(size=2.2, color=s_draw, colorscale="Rainbow",
                colorbar=dict(title="Rebaix. (m)", x=1.02, len=0.55, y=0.5),
                showscale=True, opacity=0.85),
    customdata=np.stack([s_lay, s_draw], axis=-1),
    hovertemplate=("x=%{x:.0f} m  y=%{y:.0f} m<br>"
                   "Camada %{customdata[0]}<br>"
                   "Elev=%{z:.1f} m<br>Rebaixamento=%{customdata[1]:.3f} m<extra></extra>"),
    name="Rebaixamento", showlegend=False, visible=False,
))
IDX_DRAW = 2

# --- GHB diamonds (groups: kzones + drawdown) ---
fig.add_trace(go.Scatter3d(
    x=gx, y=gy, z=gz, mode="markers",
    marker=dict(size=3.2, color="black", symbol="diamond",
                line=dict(color="white", width=0.5)),
    name="Células GHB", showlegend=True, visible=False,
    hovertemplate="GHB<br>x=%{x:.0f} y=%{y:.0f}<br>z=%{z:.1f} m<extra></extra>",
))
IDX_GHB = 3

# --- K zone clouds: one trace per zone (legend carries Kx value) ---
zone_trace_idx = []
for zi in range(nz):
    m = s_zone == zi
    kx = float(kuniq[zi])
    fig.add_trace(go.Scatter3d(
        x=sx[m], y=sy[m], z=sz[m], mode="markers",
        marker=dict(size=2.4, color=zone_colors[zi], opacity=0.9),
        name=f"Z{zi+1:02d} · Kx={kx:.3g} m/d",
        legendgroup=f"z{zi}",
        customdata=np.repeat(zi + 1, int(m.sum())),
        hovertemplate=(f"Zona Z{zi+1:02d}<br>Kx={kx:.3g} m/d<br>"
                       "x=%{x:.0f} y=%{y:.0f}<br>Elev=%{z:.1f} m<extra></extra>"),
        showlegend=True, visible=False,
    ))
    zone_trace_idx.append(len(fig.data) - 1)

total = len(fig.data)

# ----------------------------------------------------------------------------
# Tabs (updatemenu buttons toggling visibility groups)
# ----------------------------------------------------------------------------
def vis_for(group):
    v = [False] * total
    if group == "head":
        v[IDX_TERRAIN] = True
        v[IDX_HEAD] = True
    elif group == "kzones":
        for ti in zone_trace_idx:
            v[ti] = True
        v[IDX_GHB] = True
    elif group == "drawdown":
        v[IDX_DRAW] = True
        v[IDX_GHB] = True
    return v

buttons = [
    dict(label="① Carga hidráulica", method="update",
         args=[{"visible": vis_for("head")},
               {"title.text": "Autenried v02 — Carga hidráulica (fim do transiente, SP48 / t=1096 d)"}]),
    dict(label="② Zonas de K", method="update",
         args=[{"visible": vis_for("kzones")},
               {"title.text": f"Autenried v02 — Zonas de K calibradas (SS): {nz} zonas + GHB"}]),
    dict(label="③ Rebaixamento", method="update",
         args=[{"visible": vis_for("drawdown")},
               {"title.text": "Autenried v02 — Rebaixamento (SS − transiente) + GHB"}]),
]

note = (f"Malha {nlay}×{nrow}×{ncol} · {nactive:,} células ativas · "
        f"{nsp} períodos de tensão (t=0→{times[-1]:.0f} d) · "
        f"nuvem decimada p/ {ksub.size:,} pts<br>"
        f"História: MAE {HM['mae']:.3f} m · RMSE {HM['rmse']:.3f} m · "
        f"viés +{HM['bias']:.3f} m · R {HM['r']:.3f} "
        f"({HM['npts']:,} pts diários, {HM['nwells']} poços AUT) · "
        f"v02B PEST++ rodando em paralelo (independente)")

fig.update_layout(
    title=dict(text="Autenried v02 — Carga hidráulica (fim do transiente, SP48 / t=1096 d)",
               font=dict(size=17), x=0.01, xanchor="left", y=0.965, yanchor="top"),
    scene=dict(
        xaxis_title="X local (m)",
        yaxis_title="Y local (m)",
        zaxis_title="Elevação (m)",
        aspectmode="manual",
        aspectratio=dict(x=1.7, y=1.0, z=0.55),
        camera=dict(eye=dict(x=1.6, y=-1.6, z=0.9)),
    ),
    updatemenus=[dict(
        type="buttons", direction="right", showactive=True,
        x=0.62, y=1.13, xanchor="left", yanchor="top",
        buttons=buttons, pad=dict(r=8, t=4),
        bgcolor="rgba(30,30,40,0.95)", bordercolor="rgba(100,160,255,0.85)",
        borderwidth=2, font=dict(size=13, color="#e0e8ff", family="Arial"),
    )],
    annotations=[dict(
        text=note, showarrow=False, xref="paper", yref="paper",
        x=0.01, y=-0.03, xanchor="left", yanchor="top",
        font=dict(size=11, color="#9fb3d1"), align="left",
    )],
    legend=dict(x=1.02, y=0.5, yanchor="middle", font=dict(size=10),
                bgcolor="rgba(20,24,34,0.7)", title=dict(text="Zonas de K / GHB")),
    width=1400, height=900,
    template="plotly_dark",
    margin=dict(l=0, r=250, t=120, b=70),
)

OUT.parent.mkdir(parents=True, exist_ok=True)
fig.write_html(str(OUT), include_plotlyjs="cdn",
               config={"displaylogo": False, "responsive": True})
size_mb = OUT.stat().st_size / 1e6
print(f"\nWrote {OUT}  ({size_mb:.2f} MB, {total} traces)")
print("Done.")
