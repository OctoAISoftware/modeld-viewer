import os
os.environ.setdefault("OMP_NUM_THREADS", "1")
os.environ.setdefault("OPENBLAS_NUM_THREADS", "1")
os.environ.setdefault("MKL_NUM_THREADS", "1")
import json
import numpy as np
import flopy
from pathlib import Path

WS = Path("/home/suporte/modeld-flopy/autenried/Catchment_Autenried_flopy/V12_TRANSIENT_V02/mf6_workspace")

print("Loading grid from grb ...", flush=True)
grb = flopy.mf6.utils.MfGrdFile(str(WS / "gwf_tr_v02.dis.grb"))
mg = grb.modelgrid
nlay, nrow, ncol = mg.nlay, mg.nrow, mg.ncol
print("grid:", nlay, nrow, ncol, flush=True)

print("Loading sim packages (dis, npf, ic, sto, ghb, chd, rcha) ...", flush=True)
sim = flopy.mf6.MFSimulation.load(
    sim_ws=str(WS), load_only=["dis", "npf", "ic", "sto", "ghb", "chd", "rcha"],
    verbosity_level=0
)
gwf = sim.get_model()
ido = gwf.dis.idomain.array
act = ido > 0
print("idomain unique:", np.unique(ido), flush=True)
print("active cells (idomain>0):", int(act.sum()), "/", ido.size, flush=True)
# active per layer
print("active per layer:", [int(act[L].sum()) for L in range(nlay)], flush=True)

def uniq_report(name, arr):
    a = np.asarray(arr, dtype=float)
    u = np.unique(np.round(a[act], 8))
    print(f"\n== {name}: {u.size} distinct active values ==", flush=True)
    if u.size <= 40:
        for v in u:
            cnt = int(((np.round(a, 8) == v) & act).sum())
            print(f"   {v:.8g}   (cells={cnt})", flush=True)
    else:
        print("   range:", float(u.min()), "->", float(u.max()), flush=True)
        print("   first 20:", [float(x) for x in u[:20]], flush=True)
    return u

k = gwf.npf.k.array
ku = uniq_report("Kx (m/d) NPF", k)
# Kz if present
try:
    k33 = gwf.npf.k33.array
    if k33 is not None:
        uniq_report("Kz (m/d) NPF k33", k33)
except Exception as e:
    print("k33:", e)

sy = gwf.sto.sy.array
syu = uniq_report("Sy STO", sy)
ss = gwf.sto.ss.array
ssu = uniq_report("Ss STO (1/m)", ss)
try:
    iconv = gwf.sto.iconvert.array
    print("iconvert unique:", np.unique(iconv[act]))
except Exception as e:
    print("iconvert:", e)

# IC
strt = gwf.ic.strt.array
print("\n== IC strt ==", flush=True)
print("  min/max active:", float(np.nanmin(strt[act])), float(np.nanmax(strt[act])), flush=True)

# RCH (transient). recharge applied to top active cell. get sp0 and a peak sp.
rcha = gwf.rcha
try:
    rspd = rcha.recharge.get_data()
    keys = sorted(rspd.keys())
    print("\n== RCHA stress periods present:", len(keys), "keys sample:", keys[:5], "...", keys[-3:], flush=True)
    sp0 = np.asarray(rspd[keys[0]], dtype=float)
    print("  RCH sp0 shape:", sp0.shape, flush=True)
    # recharge array is typically (nrow,ncol) applied to layer1, m/d
    rflat = sp0[np.isfinite(sp0)]
    ru = np.unique(np.round(rflat, 10))
    print("  RCH sp0 distinct:", ru.size, flush=True)
    if ru.size <= 40:
        print("  vals (m/d):", [float(x) for x in ru], flush=True)
    else:
        print("  range:", float(ru.min()), float(ru.max()), flush=True)
except Exception as e:
    print("RCHA probe failed:", repr(e), flush=True)

# CHD
try:
    chd = gwf.chd.stress_period_data.get_data(0)
    print("\n== CHD sp0 cells:", len(chd), "dtype:", chd.dtype.names, flush=True)
    chead = np.array([float(x) for x in chd["head"]])
    print("  CHD head min/max:", chead.min(), chead.max(), flush=True)
except Exception as e:
    print("CHD probe failed:", repr(e), flush=True)

# GHB
ghb = gwf.ghb.stress_period_data.get_data(0)
print("\n== GHB sp0 cells:", len(ghb), "dtype:", ghb.dtype.names, flush=True)

# heads
hf = flopy.utils.HeadFile(str(WS / "gwf_tr_v02.hds"))
times = hf.get_times()
print("\n== HEAD: n times:", len(times), "last:", times[-1], flush=True)
h_last = hf.get_data(totim=times[-1])
print("  head last min/max active:",
      float(np.nanmin(np.where(act, h_last, np.nan))),
      float(np.nanmax(np.where(act, h_last, np.nan))), flush=True)

# Save the discrete zone tables to JSON for the builder + legend
out = {
    "grid": [int(nlay), int(nrow), int(ncol)],
    "nactive": int(act.sum()),
    "kx_unique_md": [float(x) for x in ku],
    "sy_unique": [float(x) for x in syu],
    "ss_unique": [float(x) for x in ssu],
    "n_times": len(times),
    "t_last": float(times[-1]),
}
Path("/home/suporte/modeld-flopy/autenried/Catchment_Autenried_flopy/V12_TRANSIENT_V02/viewer/probe_v2.json").write_text(json.dumps(out, indent=2))
print("\nWrote probe_v2.json")
print("DONE")
