import os
os.environ.setdefault("OMP_NUM_THREADS", "1")
os.environ.setdefault("OPENBLAS_NUM_THREADS", "1")
os.environ.setdefault("MKL_NUM_THREADS", "1")
import numpy as np
import flopy
from pathlib import Path

WS = Path("/home/suporte/modeld-flopy/autenried/Catchment_Autenried_flopy/V12_TRANSIENT_V02/mf6_workspace")

print("Loading grid from grb ...", flush=True)
grb = flopy.mf6.utils.MfGrdFile(str(WS / "gwf_tr_v02.dis.grb"))
mg = grb.modelgrid
print("grid:", mg.nlay, mg.nrow, mg.ncol, flush=True)
ido = mg.idomain
print("idomain shape:", None if ido is None else ido.shape, flush=True)
if ido is not None:
    print("active cells (idomain>0):", int((ido > 0).sum()), flush=True)

print("\nLoading sim packages (dis, npf, ic, ghb, chd) ...", flush=True)
sim = flopy.mf6.MFSimulation.load(
    sim_ws=str(WS), load_only=["dis", "npf", "ic", "ghb", "chd"], verbosity_level=0
)
gwf = sim.get_model()
k = gwf.npf.k.array
print("K shape:", k.shape, flush=True)
ido2 = gwf.dis.idomain.array
act = ido2 > 0
ku = np.unique(np.round(k[act], 6))
print("unique Kx values (active):", len(ku))
print(ku[:30], flush=True)

strt = gwf.ic.strt.array
print("strt shape:", strt.shape, "min/max:", float(np.nanmin(strt[act])), float(np.nanmax(strt[act])), flush=True)

ghb = gwf.ghb.stress_period_data.get_data(0)
print("GHB cells (sp0):", len(ghb), flush=True)
print("GHB dtype:", ghb.dtype.names, flush=True)

print("\nHead file times ...", flush=True)
hf = flopy.utils.HeadFile(str(WS / "gwf_tr_v02.hds"))
times = hf.get_times()
print("n times:", len(times), "first:", times[0], "last:", times[-1], flush=True)
h_last = hf.get_data(totim=times[-1])
print("head last shape:", h_last.shape, "min/max active:",
      float(np.nanmin(np.where(act, h_last, np.nan))),
      float(np.nanmax(np.where(act, h_last, np.nan))), flush=True)

# top/botm extents for vert exag
top = gwf.dis.top.array
botm = gwf.dis.botm.array
print("top min/max:", float(top.min()), float(top.max()))
print("botm min/max:", float(botm.min()), float(botm.max()))
xc = mg.xcellcenters; yc = mg.ycellcenters
print("x extent:", float(xc.min()), float(xc.max()))
print("y extent:", float(yc.min()), float(yc.max()))
print("DONE")
