import os
os.environ.setdefault("OMP_NUM_THREADS", "1")
import numpy as np, flopy
from pathlib import Path
WS = Path("/home/suporte/modeld-flopy/autenried/Catchment_Autenried_flopy/V12_TRANSIENT_V02/mf6_workspace")
sim = flopy.mf6.MFSimulation.load(sim_ws=str(WS), load_only=["dis","ghb","chd","rcha_0"], verbosity_level=0)
gwf = sim.get_model()
print("packages:", gwf.package_names, flush=True)
rch = gwf.get_package("rcha_0")
print("rch pkg:", type(rch).__name__, flush=True)
rspd = rch.recharge.get_data()
keys = sorted(rspd.keys())
print("RCH SPs:", len(keys), "keys:", keys[:6], "...", keys[-3:], flush=True)
for kk in [keys[0], keys[len(keys)//2], keys[-1]]:
    a = np.asarray(rspd[kk], dtype=float)
    fin = a[np.isfinite(a)]
    u = np.unique(np.round(fin, 12))
    print(f"  SP{kk}: shape={a.shape} distinct={u.size} vals(m/d)={[float(x) for x in u][:12]}", flush=True)
chd = gwf.chd.stress_period_data.get_data(0)
print("CHD cells:", len(chd), flush=True)
ch = np.array([float(x) for x in chd['head']]); print("CHD head min/max:", ch.min(), ch.max(), flush=True)
ghb = gwf.ghb.stress_period_data.get_data(0)
print("GHB cells:", len(ghb), "names:", ghb.dtype.names, flush=True)
hf = flopy.utils.HeadFile(str(WS/"gwf_tr_v02.hds")); t=hf.get_times()
print("HEAD ntimes:", len(t), "last:", t[-1], flush=True)
print("DONE")
