#!/usr/bin/env python3
"""
Autenried V12 Transient v02 — standalone 3D MODFLOW viewer.

Reads the calibrated v02 transient MF6 outputs (read-only), decimates the
active-cell point cloud, and writes a single self-contained Plotly HTML with
three views (Head / K zones / Drawdown), a 48-stress-period time slider, a
gray terrain surface and a GHB overlay.

Run:
    cd <V12_TRANSIENT_V02>/ && \
    ~/modeld_flopy/.venv/bin/python modflow_3d_html_viewer.py
"""

import os
import time
import numpy as np
import flopy
import plotly.graph_objects as go

# ----------------------------------------------------------------------------
HERE = os.path.dirname(os.path.abspath(__file__))
WS = os.path.join(HERE, "mf6_workspace")
OUT_HTML = os.path.join(HERE, "v02_3d_viewer.html")

N_SAMPLE = 16000          # base active-cell sample
N_GHB_SAMPLE = 4000       # GHB overlay sample
SEED = 42
HEAD_RANGE = None         # auto from data
RNG = np.random.default_rng(SEED)

# Calibration context (v02 transient history match)
CAL = dict(mae=0.237, rmse=0.299, bias=0.034, r=0.574, npts=3230, nwells=7)

CATEG_PALETTE = [
    "#1f77b4", "#ff7f0e", "#2ca02c", "#d62728", "#9467bd", "#8c564b",
    "#e377c2", "#7f7f7f", "#bcbd22", "#17becf", "#393b79", "#637939",
    "#8c6d31", "#843c39", "#7b4173", "#5254a3", "#a55194", "#6b6ecf",
]


def log(msg):
    print(f"[viewer] {msg}", flush=True)


def main():
    t0 = time.time()
    log(f"loading sim from {WS}")
    sim = flopy.mf6.MFSimulation.load(
        sim_ws=WS, verbosity_level=0,
        load_only=["dis", "npf", "ghb", "ic"],
    )
    gwf = sim.get_model()
    mg = gwf.modelgrid
    nlay, nrow, ncol = mg.nlay, mg.nrow, mg.ncol
    log(f"grid {nlay}x{nrow}x{ncol}")

    idom = mg.idomain
    if idom is None:
        idom = np.ones((nlay, nrow, ncol), dtype=int)

    # cell-center coordinates
    xc = np.asarray(mg.xcellcenters)            # (nrow, ncol)
    yc = np.asarray(mg.ycellcenters)            # (nrow, ncol)
    zc = np.asarray(mg.zcellcenters)            # (nlay, nrow, ncol)
    X = np.broadcast_to(xc, (nlay, nrow, ncol))
    Y = np.broadcast_to(yc, (nlay, nrow, ncol))
    Z = zc

    k = np.asarray(gwf.npf.k.array)             # (nlay,nrow,ncol)
    strt = np.asarray(gwf.ic.strt.array)        # SS baseline heads

    # ---- head time series -------------------------------------------------
    hf = flopy.utils.HeadFile(os.path.join(WS, "gwf_tr_v02.hds"))
    kstpkper = hf.get_kstpkper()
    times = hf.get_times()
    nsp = len(kstpkper)
    log(f"{nsp} stress-period head records")

    last = hf.get_data(kstpkper=kstpkper[-1])
    valid = (idom > 0) & np.isfinite(last) & (np.abs(last) < 1e29)
    flat_idx = np.flatnonzero(valid.ravel())
    log(f"active+valid cells: {flat_idx.size}")

    if flat_idx.size > N_SAMPLE:
        sample = np.sort(RNG.choice(flat_idx, N_SAMPLE, replace=False))
    else:
        sample = flat_idx
    log(f"base sample: {sample.size}")

    Xs = X.ravel()[sample]
    Ys = Y.ravel()[sample]
    Zs = Z.ravel()[sample]
    Ks = k.ravel()[sample]
    STRTs = strt.ravel()[sample]

    # localize horizontal coords (meters from SW corner)
    x0, y0 = float(np.nanmin(xc)), float(np.nanmin(yc))
    Xl = Xs - x0
    Yl = Ys - y0

    # vertical exaggeration so the 19 layers are visible against the km-wide grid
    x_span = float(np.nanmax(Xl) - np.nanmin(Xl)) or 1.0
    y_span = float(np.nanmax(Yl) - np.nanmin(Yl)) or 1.0
    z_span = float(np.nanmax(Zs) - np.nanmin(Zs)) or 1.0
    VE = max(1.0, round((0.45 * max(x_span, y_span)) / z_span))
    log(f"vertical exaggeration x{VE:.0f}")
    Zp = (Zs - float(np.nanmin(Zs))) * VE

    # ---- per-stress-period head + drawdown at sampled cells ---------------
    head_cols, dd_cols = [], []
    for i, kk in enumerate(kstpkper):
        h = hf.get_data(kstpkper=kk).ravel()[sample]
        h = np.where(np.abs(h) < 1e29, h, np.nan)
        head_cols.append(h.astype(np.float32))
        dd_cols.append((STRTs - h).astype(np.float32))   # SS baseline - transient
    hf.close()

    head_all = np.array(head_cols)
    hmin = float(np.nanpercentile(head_all, 1))
    hmax = float(np.nanpercentile(head_all, 99))
    dd_all = np.array(dd_cols)
    dmax = float(np.nanpercentile(np.abs(dd_all), 99)) or 1.0
    last_head = head_cols[-1]
    last_dd = dd_cols[-1]

    # ---- K zones (categorical by unique Kx) -------------------------------
    kr = np.round(Ks, 4)
    uniq = sorted(set(kr[~np.isnan(kr)].tolist()))
    kmap = {v: idx for idx, v in enumerate(uniq)}
    kzone = np.array([kmap.get(v, -1) for v in kr], dtype=float)
    n_zones = len(uniq)
    log(f"{n_zones} K zones")
    # discrete colorscale
    pal = CATEG_PALETTE[:n_zones] if n_zones <= len(CATEG_PALETTE) else \
        [CATEG_PALETTE[i % len(CATEG_PALETTE)] for i in range(n_zones)]
    if n_zones > 1:
        kscale = []
        for i, c in enumerate(pal):
            kscale.append([i / n_zones, c]); kscale.append([(i + 1) / n_zones, c])
    else:
        kscale = [[0, pal[0]], [1, pal[0]]]
    ticktext = [f"{v:g}" for v in uniq]
    tickvals = [i + 0.5 for i in range(n_zones)]

    # ---- GHB overlay ------------------------------------------------------
    ghb = gwf.ghb.stress_period_data.get_data(0)
    gx, gy, gz = [], [], []
    for rec in ghb:
        cid = rec["cellid"]
        l, r, c = cid
        gx.append(float(xc[r, c]) - x0)
        gy.append(float(yc[r, c]) - y0)
        gz.append((float(zc[l, r, c]) - float(np.nanmin(Zs))) * VE)
    gx, gy, gz = np.array(gx), np.array(gy), np.array(gz)
    if gx.size > N_GHB_SAMPLE:
        gi = np.sort(RNG.choice(gx.size, N_GHB_SAMPLE, replace=False))
        gx, gy, gz = gx[gi], gy[gi], gz[gi]
    log(f"GHB overlay points: {gx.size}")

    # ---- terrain surface (decimated top) ----------------------------------
    top = np.asarray(mg.top)
    step = max(1, ncol // 90)
    rr = np.arange(0, nrow, step)
    cc = np.arange(0, ncol, step)
    Tx = xc[np.ix_(rr, cc)] - x0
    Ty = yc[np.ix_(rr, cc)] - y0
    Tz = (top[np.ix_(rr, cc)] - float(np.nanmin(Zs))) * VE

    # ===== build figure =====================================================
    log("building figure")
    fig = go.Figure()

    # trace 0: HEAD (viridis), visible by default
    fig.add_trace(go.Scatter3d(
        x=Xl, y=Yl, z=Zp, mode="markers", name="Head",
        marker=dict(size=2.6, color=last_head, colorscale="Viridis",
                    cmin=hmin, cmax=hmax, opacity=0.85,
                    colorbar=dict(title="Head (m)", len=0.6, x=0.0)),
        customdata=Ks, hovertemplate="head %{marker.color:.2f} m<br>Kx %{customdata:.3g} m/d<extra></extra>",
        visible=True,
    ))
    # trace 1: K ZONES (categorical), hidden
    fig.add_trace(go.Scatter3d(
        x=Xl, y=Yl, z=Zp, mode="markers", name="K zones",
        marker=dict(size=2.6, color=kzone, colorscale=kscale,
                    cmin=0, cmax=n_zones, opacity=0.85,
                    colorbar=dict(title="Kx (m/d)", tickvals=tickvals,
                                  ticktext=ticktext, len=0.7, x=0.0)),
        customdata=Ks, hovertemplate="Kx %{customdata:.4g} m/d<extra></extra>",
        visible=False,
    ))
    # trace 2: DRAWDOWN (RdBu, centered), hidden
    fig.add_trace(go.Scatter3d(
        x=Xl, y=Yl, z=Zp, mode="markers", name="Drawdown",
        marker=dict(size=2.6, color=last_dd, colorscale="RdBu", reversescale=True,
                    cmin=-dmax, cmax=dmax, opacity=0.85,
                    colorbar=dict(title="Drawdown (m)<br>SS−transient", len=0.6, x=0.0)),
        hovertemplate="drawdown %{marker.color:.2f} m<extra></extra>",
        visible=False,
    ))
    # trace 3: GHB overlay (black diamonds)
    fig.add_trace(go.Scatter3d(
        x=gx, y=gy, z=gz, mode="markers", name="GHB cells",
        marker=dict(size=3.4, color="black", symbol="diamond", opacity=0.95),
        hovertemplate="GHB cell<extra></extra>",
        visible=False,
    ))
    # trace 4: terrain surface (gray)
    fig.add_trace(go.Surface(
        x=Tx, y=Ty, z=Tz, name="Terrain",
        colorscale="Greys", showscale=False, opacity=0.32,
        hoverinfo="skip", visible=True,
    ))

    # ---- view toggle buttons (Head / K zones / Drawdown) ------------------
    def vis(head, kz, dd, ghb_on):
        return [head, kz, dd, ghb_on, True]   # terrain always on

    buttons = [
        dict(label="Head", method="update",
             args=[{"visible": vis(True, False, False, False)}]),
        dict(label="K zones", method="update",
             args=[{"visible": vis(False, True, False, True)}]),
        dict(label="Drawdown", method="update",
             args=[{"visible": vis(False, False, True, True)}]),
    ]

    # ---- time slider (restyle head[0] + drawdown[2] colors) ---------------
    steps = []
    for i, kk in enumerate(kstpkper):
        steps.append(dict(
            method="restyle",
            args=[{"marker.color": [head_cols[i], dd_cols[i]]}, [0, 2]],
            label=f"{int(times[i])}d",
        ))
    sliders = [dict(active=nsp - 1, currentvalue={"prefix": "Day "},
                    pad={"t": 40}, steps=steps)]

    cap = (f"Autenried V12 Transient v02 — calibrated history match: "
           f"MAE {CAL['mae']} m · RMSE {CAL['rmse']} m · bias +{CAL['bias']} m · "
           f"R {CAL['r']} ({CAL['npts']} daily pts, {CAL['nwells']} AUT wells)  ·  "
           f"grid {nlay}×{nrow}×{ncol}, {flat_idx.size:,} active cells "
           f"(showing {sample.size:,}), vert. exagg ×{VE:.0f}")

    fig.update_layout(
        title=dict(text=cap, font=dict(size=12)),
        scene=dict(
            xaxis_title="x (m)", yaxis_title="y (m)",
            zaxis_title=f"elevation (m, ×{VE:.0f})",
            aspectmode="data",
            camera=dict(eye=dict(x=1.5, y=-1.6, z=1.1)),
            bgcolor="white",
        ),
        updatemenus=[dict(type="buttons", direction="right", showactive=True,
                          x=0.0, y=1.08, xanchor="left", buttons=buttons)],
        sliders=sliders,
        margin=dict(l=0, r=0, t=60, b=0),
        paper_bgcolor="white",
        legend=dict(x=0.0, y=0.0),
    )

    log(f"writing {OUT_HTML}")
    fig.write_html(OUT_HTML, include_plotlyjs=True, full_html=True,
                   config={"responsive": True})
    sz = os.path.getsize(OUT_HTML)
    log(f"DONE: {OUT_HTML} ({sz/1e6:.2f} MB) in {time.time()-t0:.1f}s")


if __name__ == "__main__":
    main()
